Param (
    [Parameter(mandatory = $true)][string]$AccessToken, # To receive GCP access token
    [Parameter(mandatory = $true)][string]$Org, # To receive Apigee Organization where action will be performed      
    [Parameter(mandatory = $true)][string]$Action, # To receive type of action script shall perform
    [Parameter(mandatory = $false)][string]$ApiproductName, # To receive TargetServer name
    [Parameter(mandatory = $false)][string]$AdhocJsonBody # To receive JSON body for Create or Update Action
)

# Load utility functions
. "$PSScriptRoot\utilities.ps1"

# Set Variables 

$headers = @{Authorization = "Bearer $AccessToken" }
if ( $Action -ne "Delete") {
    $sourceOrg = Get-SourceOrg -targetOrg $Org  #call utility function from utilities script
    $productsDirectory = "./$sourceOrg/apiproducts"
    Set-Location $productsDirectory
    $files = Get-ChildItem *.json
}

$apigeeDomain = "https://apigee.googleapis.com/v1/organizations/$Org/apiproducts"

$ApiproductNameValid = ![string]::IsNullOrEmpty($ApiproductName) -And ![string]::IsNullOrWhitespace($ApiproductName) -And $ApiproductName -ne "null"
$adhocJsonDataValid = ![string]::IsNullOrEmpty($AdhocJsonBody) -And ![string]::IsNullOrWhitespace($AdhocJsonBody) -And $AdhocJsonBody -ne "null"

if ( $Action -eq "ImportAll" ) {
    Write-Host "Importing ApiProducts"
    $successCount = 0
    $failureCount = 0
    $failedApiProductName = @()
    foreach ($file in $files ) {
        $requestPayload = Get-Content $file | ConvertFrom-Json
        $json_template = @{
            apiResources  = ($requestPayload.apiResources -join ", ")
            approvalType  = $requestPayload.approvalType
            attributes    = $requestPayload.attributes
            description   = $requestPayload.description
            displayName   = $requestPayload.displayName
            environments  = ($requestPayload.environments -join ", ")
            name          = $requestPayload.name
            proxies       = ($requestPayload.proxies -join ", ")
            quota         = $requestPayload.quota
            quotaInterval = $requestPayload.quotaInterval
            quotaTimeUnit = $requestPayload.quotaTimeUnit
        }
        $reqPayload = $json_template | ConvertTo-Json
        Write-Host $reqPayload
		
        try { 
            Invoke-WebRequest -Uri $apigeeDomain -Method 'POST' -ContentType 'application/json; charset=utf-8' -Body $reqPayload -Headers $headers | Select-Object -Expand Content
            $successCount++
        }
        catch {
            # Handle any other exceptions that may occur
            Write-Host "An error occurred while importing ApiProduct $($requestPayload.name) : $_"
            $failureCount++
            $failedApiProductName += $($requestPayload.name)
        }
    }
    $summary = "ApiProducts Import All:- Total $($successCount + $failureCount) Succeeded $successCount Failed $failureCount. Failed ApiProduct Names $($failedApiProductName -join ",")"
    if ( $failureCount -gt 0 ) {
        Write-Error $summary
    }
    else {
        Write-Host $summary
    }
}
elseif ( $Action -eq "Create" -And !$adhocJsonDataValid ) {
    if ( $ApiproductNameValid ) { 
        foreach ($file in $files ) {
            $requestPayload = Get-Content $file | ConvertFrom-Json
            $appname = $($requestPayload.name)
            if ($appname -eq $ApiproductName) {
                foreach ($attribute in $requestPayload.attributes) {
                    $attributeObj = @{
                        name  = $attribute.name
                        value = $attribute.value
                    }
                    $attributes += $attributeObj
                }
                Write-Host "Creating ApiProduct $ApiproductName"
                $json_template = @{
                    apiResources  = ($requestPayload.apiResources -join ", ")
                    approvalType  = $requestPayload.approvalType
                    attributes    = $attributes
                    description   = $requestPayload.description
                    displayName   = $requestPayload.displayName
                    environments  = ($requestPayload.environments -join ", ")
                    name          = $requestPayload.name
                    proxies       = ($requestPayload.proxies -join ", ")
                    quota         = $requestPayload.quota
                    quotaInterval = $requestPayload.quotaInterval
                    quotaTimeUnit = $requestPayload.quotaTimeUnit
                }
    
                $reqPayload = $json_template | ConvertTo-Json
                Write-Host $reqPayload
                Invoke-WebRequest -Uri $apigeeDomain -Method 'POST' -ContentType 'application/json; charset=utf-8' -Body $reqPayload -Headers $headers | Select-Object -Expand Content
            } 
        }
    }
    else {
        Write-Error "ApiProduct Name Required For Create Action"
   	}
}
elseif ( $Action -eq "Update" -And !$adhocJsonDataValid ) {
    if ( $ApiproductNameValid ) {
        foreach ($file in $files ) {
            $requestPayload = Get-Content $file | ConvertFrom-Json
            $productName = $requestPayload.name
            if ($productName -eq $ApiproductName) {
                foreach ($attribute in $productItem.attributes) {
                    $attributeObj = @{
                        name  = $attribute.name
                        value = $attribute.value
                    }
                    $attributes += $attributeObj
                }
                Write-Host "Updating ApiProduct $ApiproductName"
                $URI = "$apigeeDomain/$ApiproductName"
                $json_template = @{
                    apiResources  = ($requestPayload.apiResources -join ", ")
                    approvalType  = $requestPayload.approvalType
                    attributes    = $requestPayload.attributes
                    description   = $requestPayload.description
                    displayName   = $requestPayload.displayName
                    environments  = ($requestPayload.environments -join ", ")
                    name          = $requestPayload.name
                    proxies       = ($requestPayload.proxies -join ", ")
                    quota         = $requestPayload.quota
                    quotaInterval = $requestPayload.quotaInterval
                    quotaTimeUnit = $requestPayload.quotaTimeUnit
                }
                $reqPayload = $json_template | ConvertTo-Json
                Write-Host $reqPayload

                Invoke-RestMethod -Uri $URI -Method 'PUT' -ContentType 'application/json; charset=utf-8' -Body $reqPayload -Headers $headers
            }
        }
    }
    else {
        Write-Error "ApiProduct Name Required For Update Action"
   	}
}
elseif ( $Action -eq "Delete" ) {
    if ( $ApiproductNameValid ) {
		
    Write-host "Deleting ApiProduct $ApiproductName"

    $Uri = "$apigeeDomain/$ApiproductName"
    Invoke-WebRequest -Uri $Uri -Method 'DELETE' -ContentType 'application/json; charset=utf-8' -Headers $headers | Select-Object -Expand Content
		
}
else {
    Write-Error "ApiProduct Name Required For Delete Action"
}
}
elseif ( ( $Action -eq "Create" -Or $Action -eq "Update" ) -And $adhocJsonDataValid) {
    if ( $Action -eq "Create" ) {
        Write-Host "Creating ApiProduct with Adhoc Json Body $AdhocJsonBody"
        $requestPayload = $AdhocJsonBody | ConvertFrom-Json | ConvertFrom-Json
        foreach ($attribute in $requestPayload.attributes) {
            $attributeObj = @{
                name  = $attribute.name
                value = $attribute.value
            }
            $attributes += $attributeObj
        }
        $json_template = @{
            apiResources  = @($requestPayload.apiResources)
            approvalType  = $requestPayload.approvalType
            attributes    = $attributes
            description   = $requestPayload.description
            displayName   = $requestPayload.displayName
            environments  = @($requestPayload.environments)
            name          = $requestPayload.name
            proxies       = @($requestPayload.proxies)
            quota         = $requestPayload.quota
            quotaInterval = $requestPayload.quotaInterval
            quotaTimeUnit = $requestPayload.quotaTimeUnit
        }
        $reqPayload = $json_template | ConvertTo-Json
        Invoke-WebRequest -Uri $apigeeDomain -Method 'POST' -ContentType 'application/json; charset=utf-8' -Body $reqPayload -Headers $headers | Select-Object -Expand Content
    }
    elseif ( $Action -eq "Update" ) {
        Write-Host "Updating ApiProduct with Adhoc Json Body $AdhocJsonBody"
		
        $requestPayload = $AdhocJsonBody | ConvertFrom-Json | ConvertFrom-Json
        foreach ($attribute in $requestPayload.attributes) {
            $attributeObj = @{
                name  = $attribute.name
                value = $attribute.value
            }
            $attributes += $attributeObj
        }
        $json_template = @{
            apiResources  = @($requestPayload.apiResources)
            approvalType  = $requestPayload.approvalType
            attributes    = $attributes
            description   = $requestPayload.description
            displayName   = $requestPayload.displayName
            environments  = @($requestPayload.environments)
            name          = $requestPayload.name
            proxies       = @($requestPayload.proxies)
            quota         = $requestPayload.quota
            quotaInterval = $requestPayload.quotaInterval
            quotaTimeUnit = $requestPayload.quotaTimeUnit
        }
        $reqPayload = $json_template | ConvertTo-Json
    
        $Uri = "$apigeeDomain/$($requestPayload.name)"
        Invoke-WebRequest -Uri $Uri -Method 'PUT' -ContentType 'application/json; charset=utf-8' -Body $reqPayload -Headers $headers | Select-Object -Expand Content
    }
}
else {
    Write-Error "Invalid Action"
}
