Param (
    [Parameter(mandatory = $true)][string]$AccessToken, # To receive GCP access token
    [Parameter(mandatory = $true)][string]$Org, # To receive Apigee Organization where action will be performed      
    [Parameter(mandatory = $true)][string]$Action, # To receive type of Action script shall perform
    [Parameter(mandatory = $true)][string]$SourceEnv, # To receive Repo Environment from where to take Target Server data
    [Parameter(mandatory = $true)][string]$TargetEnv, # To receive Apigee Environment where Target Server will be deployed
    [Parameter(mandatory = $false)][string]$TargetServerName, # To receive Target Server name on which Action will be performed
    [Parameter(mandatory = $false)][string]$AdhocJsonBody # To receive JSON body for Create or Update Action
)

# Load utility functions
. "$PSScriptRoot\utilities.ps1"

# Set Variables 

$headers = @{Authorization = "Bearer $AccessToken" }
if ( $Action -ne "Delete") {
    $sourceOrg = Get-SourceOrg -targetOrg $Org  #call utility function from utilities script
    $targetServerDirectory = "./$sourceOrg/environments/$SourceEnv/target-servers"
    Set-Location $targetServerDirectory
    $files = Get-ChildItem *.json
}
$apigeeDomain = "https://apigee.googleapis.com/v1/organizations/$Org/environments/$TargetEnv/targetservers"

$targetServerNameValid = ![string]::IsNullOrEmpty($TargetServerName) -And ![string]::IsNullOrWhitespace($TargetServerName) -And $TargetServerName -ne "null"
$adhocJsonDataValid = ![string]::IsNullOrEmpty($AdhocJsonBody) -And ![string]::IsNullOrWhitespace($AdhocJsonBody) -And $AdhocJsonBody -ne "null"


if ( $Action -eq "ImportAll" ) {
    Write-Host "Importing TragetServers"
    $successCount = 0
    $failureCount = 0
    $failedTargetServerName = @()
    foreach ($file in $files ) {
        $requestPayload = Get-Content $file | ConvertFrom-Json
        $reqPayload = $requestPayload | ConvertTo-Json
        Write-Host $reqPayload

        try { 
            Invoke-WebRequest -Uri $apigeeDomain -Method 'POST' -ContentType 'application/json; charset=utf-8' -Body $reqPayload -Headers $headers | Select-Object -Expand Content
            $successCount++
        }
        catch {
            # Handle any other exceptions that may occur
            Write-Host "An error occurred while importing $($requestPayload.name) : $_"
            $failureCount++
            $failedTargetServerName += $($requestPayload.name)
        }
    }
    $summary = "Target Servers Import All:- Total $($successCount + $failureCount) Succeeded $successCount Failed $failureCount. Failed Target Server Names $($failedTargetServerName -join ",")"
    if ( $failureCount -gt 0 ) {
        Write-Error $summary
    }
    else {
        Write-Host $summary
   	}
}
elseif ( $Action -eq "Create" -And !$adhocJsonDataValid ) {
    if ( $targetServerNameValid ) { 
        foreach ($file in $files ) {
            $requestPayload = Get-Content $file | ConvertFrom-Json
            if ( $($requestPayload.name) -eq $TargetServerName ) {
                Write-Host "Creating TragetServer with name $TargetServerName"
                $reqPayload = $requestPayload | ConvertTo-Json
                Write-Host $reqPayload
	
                Invoke-WebRequest -Uri $apigeeDomain -Method 'POST' -ContentType 'application/json; charset=utf-8' -Body $reqPayload -Headers $headers | Select-Object -Expand Content
            } 
        }
    }
    else {
        Write-Error "Target Server Name Required For Create Action"
   	}
}
elseif ( $Action -eq "Update" -And !$adhocJsonDataValid ) {
    if ( $targetServerNameValid ) {
        foreach ($file in $files ) {
            $requestPayload = Get-Content $file | ConvertFrom-Json
            if ( $($requestPayload.name) -eq $TargetServerName ) {
                Write-Host "Updating TragetServer with name $TargetServerName"
                $reqPayload = $requestPayload | ConvertTo-Json
                Write-Host $reqPayload
	
                $Uri = "$apigeeDomain/$TargetServerName"
                Invoke-WebRequest -Uri $Uri -Method 'PUT' -ContentType 'application/json; charset=utf-8' -Body $reqPayload -Headers $headers | Select-Object -Expand Content
            }
        }
    }
    else {
        Write-Error "Target Server Name Required For Update Action"
   	}
}
elseif ( $Action -eq "Delete" ) {
    if ( $targetServerNameValid ) {
		
        Write-Host "Deleting TragetServer with name $TargetServerName"

        $Uri = "$apigeeDomain/$TargetServerName"
        Invoke-WebRequest -Uri $Uri -Method 'DELETE' -ContentType 'application/json; charset=utf-8' -Headers $headers | Select-Object -Expand Content
		
    }
    else {
        Write-Error "Target Server Name Required For Delete Action"
   	}
}
elseif ( ( $Action -eq "Create" -Or $Action -eq "Update" ) -And $adhocJsonDataValid) {
    if ( $Action -eq "Create" ) {
        Write-Host "Creating TragetServer with Adhoc Json Body $AdhocJsonBody"

        $requestPayload = $AdhocJsonBody | ConvertFrom-Json | ConvertFrom-Json
        $reqPayload = $requestPayload | ConvertTo-Json

        Invoke-WebRequest -Uri $apigeeDomain -Method 'POST' -ContentType 'application/json; charset=utf-8' -Body $reqPayload -Headers $headers | Select-Object -Expand Content
    }
    elseif ( $Action -eq "Update" ) {
        Write-Host "Updating TragetServer with Adhoc Json Body $AdhocJsonBody"
		
        $requestPayload = $AdhocJsonBody | ConvertFrom-Json | ConvertFrom-Json
        $reqPayload = $requestPayload | ConvertTo-Json
    
        $Uri = "$apigeeDomain/$($requestPayload.name)"
        Invoke-WebRequest -Uri $Uri -Method 'PUT' -ContentType 'application/json; charset=utf-8' -Body $reqPayload -Headers $headers | Select-Object -Expand Content
    }
    else {
        Write-Error "Invalid Action with Adhoc Json Body Parameter"
   	}
} 
else {
    Write-Error "Invalid Action"
}
