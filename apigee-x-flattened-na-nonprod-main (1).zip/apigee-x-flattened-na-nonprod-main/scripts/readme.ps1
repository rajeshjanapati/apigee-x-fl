$orgHeading = ""
$basePath = Get-Location
 
$ignoreDirectories = @(".devcontainer", ".github", "readme", "scripts")
$orgList = @()
 
Get-ChildItem $basePath -Directory | 
Foreach-Object {
    $dirName = Split-Path -Path $_.FullName -Leaf
    if ( $ignoreDirectories -notcontains $dirName ) {
        $orgList += $dirName
        $orgHeading = $orgHeading + "# [$dirName](./$dirName/README.MD) `n"
        Write-Host "This is directory $dirName"
    } 
}
$githubHeading = "# [Apigee X Artifacts Mangement Workflows](./.github/workflows/README.MD) `n" 
 
$orgBody = @"
 
# Apigee Artifacts

Welcome to the Apigee Artifacts repository! This repository contains details about Apigee X artifacts, including Proxies, SharedFlows, Environment Config Variables like Key-Value Maps (KVMs), Target Servers, Environment-level proxies, organization-level KVMs, developer details, App details, API Product details, and master proxy deployment details. These artifacts are managed and implemented using Apigee Management APIs within PowerShell scripts, integrated with GitHub Actions workflows.

**Key Focus Areas:**
- Apigee X
- GitHub Actions Workflow
- Apigee API Management APIs
- PowerShell Scripting

**Overview:**

This project automates the nightly extraction of Apigee X Artifacts. The workflow is scheduled to run at specific times using cron expressions. When executed, the workflow utilizes Apigee Management APIs to create Proxies, SharedFlows, Environment Config Variables, and more within this GitHub repository. Each item is detailed and documented as part of the process.

Please find the nightly extracted data of apigee-x in the artifacts branch, for configuration variables like KVMs, Apps data has been encrypted, including KVM Entries, consumer key, and consumer secret, and stored in specific file paths at both the organization and environment levels. For each extracted item, in-depth details are provided to offer a comprehensive understanding. Proxies and shared flows, for instance, include information such as policies, base paths, and deployed environments, stored at respective filepaths for both organization and environment levels. Developers and API Products have their complete details stored in respective file paths.

**Specific Features:**
* Export all artifacts from Apigee X and Push changes Github
* Handling Newly created artifacts
* Handling Deleted Artifacts, if any user performed a hard delete
* AES Encryption is done for KVM Entries and ConsumerKey & consumerSecret for Apps
* For Encryption and Decryption same key has been used.


For a comprehensive list of Apigee API Management APIs, please visit the [Apigee API Management APIs page](https://cloud.google.com/apigee/docs/reference/apis/apigee/rest).

For any questions or contributions, please feel free to reach out and collaborate with us!


## Github Action Workflows
$githubHeading
 
## Orgs
$orgHeading
 
"@
 
Write-Host $orgBody
$outOrgPath = "$basePath/README.MD"
$orgBody | Out-File -FilePath $outOrgPath

$basePathWorkflow = "$basePath/.github/workflows"


$workflowBody = @"

# Apigee X Artifacts Mangement Workflow

## [Apigee X Export Mangement Workflow](./apigee-x-artifacts.yml)
This Workflow exports all the artifacts from Apigee X organization and stores it in Github.

* It runs based on a schedule which triggers the workflow everyday at 10:00 AM UTC.
* It can also be triggered manually anytime required.
* The README files are automatically generated as part of this workflow. README files will be generated everytime this workflow is triggered.
* It use Github Auth App Token to Pull, Commit and Push the code to repo.
* A Summary file is generated with every workflow run to summarize and record failure of export for each type of artifacts.

## [Api Products Mangement Workflow](./apiproducts.yml)
This Workflow can perform below actions on Api Products

**Actions:**
* **ImportAll:-** To Import All the Api Products for a given organization. Inputs required is **Target Organization**. It takes Github repo as source.
* **Create:-** To Create a single Api Product for a given organization. Inputs required is **Target Organization**. **Api Product Name** is required if source is Github repo, otherwise we can provide **Adhoc JSON Request Body**.
* **Update:-** To Update a single Api Product for a given organization. Inputs required is **Target Organization**. **Api Product Name** is required if source is Github repo, otherwise we can provide **Adhoc JSON Request Body**.
* **Delete:-** To Delete a single Api Product for a given organization. Inputs required are **Target Organization** and **Api Product Name**.

## [Apps Mangement Workflow](./apps.yml)
This Workflow can perform below actions on Apps

**Actions:**
* **ImportAll:-** To Import All the Apps for a given organization. Inputs required is **Target Organization**. It takes Github repo as source.
* **Create:-** To Create a single App for a given organization. Inputs required are **Target Organization** and **Developer Email**. **App Name** is required if source is Github repo, otherwise we can provide **Adhoc JSON Request Body**.
* **Update:-** To Update a single App for a given organization. Inputs required are **Target Organization** and **Developer Email**. **App Name** is required if source is Github repo, otherwise we can provide **Adhoc JSON Request Body**.
* **Delete:-** To Delete a single App for a given organization. Inputs required are **Target Organization, Developer Email** and **App Name**.

## [Developers Mangement Workflow](./developers.yml)
This Workflow can perform below actions on Developers

**Actions:**
* **ImportAll:-** To Import All the Developers for a given organization. Inputs required is **Target Organization**. It takes Github repo as source.
* **Create:-** To Create a single Developer for a given organization. Inputs required is **Target Organization**. **Developer Email** is required if source is Github repo, otherwise we can provide **Adhoc JSON Request Body**.
* **Update:-** To Update a single Developer for a given organization. Inputs required is **Target Organization**. **Developer Email** is required if source is Github repo, otherwise we can provide **Adhoc JSON Request Body**.
* **Delete:-** To Delete a single Developer for a given organization. Inputs required are **Target Organization** and **Developer Email**.

## [FlowHooks Mangement Workflow](./flowhooks.yml)
This Workflow can perform below actions on FlowHooks

**Actions:**
* **ImportAll:-** To Import All the FlowHooks for a given organization in given environment. Inputs required are **Target Organization**, **Target Environment** and **Source Environment**. It takes Github repo as source.
* **ImportFlowhookFile:-** To Import a single FlowHook for a given organization in given environment. Inputs required are **Target Organization**, **Target Environment**, **Source Environment** and **FlowHook Type**. It takes Github repo as source.
* **ImportFlowhookAdhoc:-** To Import a single FlowHook for a given organization in given environment. Inputs required are **Target Organization**, **Target Environment** and **Adhoc JSON Request Body**.

## [Keystores Mangement Workflow](./keystores.yml)
This Workflow can perform below actions on Keystores

**Actions:**
* **ImportAll:-** To Import All the Keystores for a given organization in given environment. Inputs required is **Target Organization**, **Target Environment** and **Source Environment**. It takes Github repo as source.
* **Create:-** To Create a single Keystore for a given organization in given environment. Inputs required are **Target Organization** and **Target Environment**. **Source Environment** and **Keystore Name** is required if source is Github repo, otherwise we can provide **Adhoc JSON Request Body**.
* **Delete:-** To Delete a single Keystore for a given organization in given environment. Inputs required are **Target Organization**, **Target Environment** and **Keystore Name**.

## [Key Value Maps Mangement Workflow](./kvms.yml)
This Workflow can perform below actions on Key Value Maps

**Actions:**
* **ImportAll:-** To Import All the KVMs and their Key Value Entries for a given organization in given environment. Inputs required are **Target Organization**, **Target Environment** and **Source Environment**. It takes Github repo as source.
* **Create:-** To Create a single KVM and Key Value Entry for a given organization in given environment. Inputs required are **Target Organization** and **Target Environment**. **KVM Name** is required if source is Github repo, otherwise we can provide **Adhoc JSON Request Body** to Create a KVM or provide **KVM Name** and **Adhoc JSON Request Body** to create a single Key Value Entry.
* **Delete:-** To Delete a single KVM and Key Value Entry for a given organization in given environment. Inputs required are **Target Organization** and **Target Environment**. **KVM Name** is required to Delete a KVM and all its Key Value Entries or **KVM Name** and **KVM Key Name** are required to Delete a Key Value Entry.

## [Master Redeployment Mangement Workflow](./master-redeployment.yml)
This Workflow is used to recreate an Organization from scratch in case of disaster recovery situation.
It is an orchestration workflow which calls all other artifacts script in parallel wherever possible.

**Actions/Level of Redeployment:**
* **Organization:-** To Import and Deploy whole organization and all its artifacts including environment level artifacts for a given organization. Inputs required are **Target Organization** and **Revision Import Depth**.
* **Environment:-** To Import all the artifacts of a given environment for a given organization. Inputs required are **Target Organization** and **Target Environment**.
* **Proxies And Shared Flows:-** To Deploy all the Proxies and Shared Flows for a given organization in given environment. It deploys same Proxies and Shared Flows and their respective versions as present in Guthub repo Environment folder. Inputs required are **Target Organization** and **Target Environment**.

**Parallel Jobs in Workflow:**
* **Get-Environment:-** To get the environment list for a Organization redeployment.
* **Import-Proxies:-** To Import all the Proxies with either All or Top5 revison based on **Revision Import Depth**.
* **Import-Shared-Flows:-** To Import all the Shared Flows with either All or Top5 revison based on **Revision Import Depth**.
* **Import-Developers-ApiProducts-And-Apps:-** To Import all Developers, ApiProducts and Apps.
* **Deploy-Proxies-Shared-Flows-And-FlowHooks:-** To Deploy all Proxies, Shared Flows and FlowHooks to a single environment. It has dependenncy on **Get-Environment**, **Import-Proxies** and **Import-Shared-Flows** jobs.
* **Import-KVMs:-** To Import all KVMs to a single environment. It has dependenncy on **Get-Environment** job.
* **Import-Target-Servers:-** To Import all Target Servers to a single environment. It has dependenncy on **Get-Environment** job.
* **Import-Keystores:-** To Import all Keystores to a single environment. It has dependenncy on **Get-Environment** job.
* **Import-Resources:-** To Import all Resources to a single environment. It has dependenncy on **Get-Environment** job.

## [Metrics Logging Schedule Workflow](./metrics-logging-schedule.yml)
This Workflow extracts HostStats from Apigee X instance and create a log of that data in New Relic.

* It runs based on a schedule which triggers the workflow every 10 minutes.
* Data Points extracted are **tps, sum(cache_hit), sum(is_error), max(request_processing_latency), max(target_response_time), max(total_response_time), sum(target_error), sum(ax_cache_executed), sum(policy_error), sum(message_count)**.
* It logs the data for each environment of each organization to a separate index based on environment in New Relic.

## [Proxies Mangement Workflow](./proxies.yml)
This Workflow can perform below actions on Proxies. All actions takes Github repo as source.

**Actions:**
* **ImportProxyVersion:-** To Import specific version of given Proxy for a given organization. Inputs required are **Target Organization**, **Proxy Name** and **Repo Proxy Version**.
* **ImportTop5ProxyVersion:-** To Import latest 5 version of given Proxy for a given organization. Inputs required are **Target Organization** and **Proxy Name**.
* **DeleteProxyVersion:-** To Delete specific version of given Proxy for a given organization. Inputs required are **Target Organization**, **Proxy Name** and **Apigee X Proxy Version**.
* **DeleteProxy:-** To Delete Proxy for a given organization. Inputs required are **Target Organization** and **Proxy Name**.
* **Deploy:-** To Deploy specific version of given Proxy for a given organization to given Environment. Inputs required are **Target Organization**, **Proxy Name**, **Apigee X Proxy Version** and **Target Environment**.
* **Undeploy:-** To Undeploy specific version of given Proxy for a given organization from given Environment. Inputs required are **Target Organization**, **Proxy Name**, **Apigee X Proxy Version** and **Target Environment**.
* **ImportAndDeployProxy:-** To Import and Deploy specific version of given Proxy for a given organization to given Environment. Inputs required are **Target Organization**, **Proxy Name**, **Repo Proxy Version** and **Target Environment**.
* **CodeQualityCheckOnly:-** To perform Code Quality Check on specific version of given Proxy for a given organization. Inputs required are **Target Organization**, **Proxy Name** and **Repo Proxy Version**.
* **ImportAllProxyVersions:-** To Import all versions of given Proxy for a given organization. Inputs required are **Target Organization** and **Proxy Name**.
* **DeployAllProxies:-** To Deploy all Proxies to a given environment for a given organization. It deploys the same proxies and versions which were are present in environment-> proxies folder of github repo. Inputs required are **Target Organization** and **Target Environment**.

## [Resources Mangement Workflow](./resources.yml)
This Workflow can perform below actions on Resources

**Actions:**
* **ImportAll:-** To Import All the Resources for a given organization in given environment. Inputs required are **Target Organization**, **Target Environment** and **Source Environment**. It takes Github repo as source.
* **Create:-** To Create a single Resource for a given organization in given environment. Inputs required are **Target Organization** and **Target Environment**. **Resource Name** is required if source is Github repo, otherwise we can provide **Adhoc Base64 String** and **Resource Type**.
* **Update:-** To Update a single Resource for a given organization in given environment. Inputs required are **Target Organization** and **Target Environment**. **Resource Name** is required if source is Github repo, otherwise we can provide **Adhoc Base64 String** and **Resource Type**.
* **Delete:-** To Delete a single Resource for a given organization in given environment. Inputs required are **Target Organization**, **Target Environment** and **Resource Name**.

## [Shared Flows Mangement Workflow](./sharedflows.yml)
This Workflow can perform below actions on Shared Flows. All actions takes Github repo as source.

**Actions:**
* **ImportSharedflowVersion:-** To Import specific version of given Shared Flow for a given organization. Inputs required are **Target Organization**, **Shared Flow Name** and **Repo Shared Flow Version**.
* **ImportTop5SharedflowVersion:-** To Import latest 5 version of given Shared Flow for a given organization. Inputs required are **Target Organization** and **Shared Flow Name**.
* **DeleteSharedflowVersion:-** To Delete specific version of given Shared Flow for a given organization. Inputs required are **Target Organization**, **Shared Flow Name** and **Apigee X Shared Flow Version**.
* **DeleteSharedflow:-** To Delete Shared Flow for a given organization. Inputs required are **Target Organization** and **Shared Flow Name**.
* **Deploy:-** To Deploy specific version of given Shared Flow for a given organization to given Environment. Inputs required are **Target Organization**, **Shared Flow Name**, **Apigee X Shared Flow Version** and **Target Environment**.
* **Undeploy:-** To Undeploy specific version of given Shared Flow for a given organization from given Environment. Inputs required are **Target Organization**, **Shared Flow Name**, **Apigee X Shared Flow Version** and **Target Environment**.
* **ImportAndDeploySharedflow:-** To Import and Deploy specific version of given Shared Flow for a given organization to given Environment. Inputs required are **Target Organization**, **Shared Flow Name**, **Repo Shared Flow Version** and **Target Environment**.
* **CodeQualityCheckOnly:-** To perform Code Quality Check on specific version of given Shared Flow for a given organization. Inputs required are **Target Organization**, **Shared Flow Name** and **Repo Shared Flow Version**.
* **ImportAllSharedFlowVersions:-** To Import all versions of given Shared Flow for a given organization. Inputs required are **Target Organization** and **Shared Flow Name**.
* **DeployAllProxies:-** To Deploy all Shared Flows to a given environment for a given organization. It deploys the same proxies and versions which were are present in environment-> shared-flows folder of github repo. Inputs required are **Target Organization** and **Target Environment**.

## [Target Servers Mangement Workflow](./targetservers.yml)
This Workflow can perform below actions on Target Servers

**Actions:**
* **ImportAll:-** To Import All the Target Servers for a given organization in given environment. Inputs required are **Target Organization**, **Target Environment** and **Source Environment**. It takes Github repo as source.
* **Create:-** To Create a single Target Server for a given organization in given environment. Inputs required are **Target Organization** and **Target Environment**. **Target Servers Name** is required if source is Github repo, otherwise we can provide **Adhoc JSON Request Body**.
* **Update:-** To Update a single Target Server for a given organization in given environment. Inputs required are **Target Organization** and **Target Environment**. **Target Servers Name** is required if source is Github repo, otherwise we can provide **Adhoc JSON Request Body**.
* **Delete:-** To Delete a single Target Server for a given organization in given environment. Inputs required are **Target Organization**, **Target Environment** and **Target Server Name**.

"@

Write-Host $workflowBody
$outWorkflowPath = "$basePathWorkflow/README.MD"
$workflowBody | Out-File -FilePath $outWorkflowPath

$orgList | ForEach-Object {
    $org = $_
    $ignoreOrgArtifacts = @("org-kvms")
    $basePathOrg = "$basePath/$org"
    $artifactHeading = ""
    $artifactList = @()

    Get-ChildItem $basePathOrg -Directory | Foreach-Object {
        $dirName = Split-Path -Path $_.FullName -Leaf
        if ( $ignoreOrgArtifacts -notcontains $dirName ) {    
            $artifactList += $dirName
            $artifactHeading = $artifactHeading + "## [$dirName](./$dirName/README.MD)`n"
            Write-Host "This is directory $dirName"
        }    
    }

    $artifactsBody = @"
 
# Org Artifact Configurations
$artifactHeading
 
"@

    Write-Host $artifactsBody
    $outArtifactPath = "$basePathOrg/README.MD"
    $artifactsBody | Out-File -FilePath $outArtifactPath

}

$orgList | ForEach-Object {
    $org = $_
    
    $artifactList | ForEach-Object {
        $artifact = $_
        
        if ( $artifact -eq "apps" ) {
            $basePathApps = "$basePath/$org/apps"
            $appsHeading = ""
            $appProductsList = @()

            Get-ChildItem $basePathApps *.json | Foreach-Object {
                $app = Split-Path -Path $_.FullName -Leaf
                $appPath = "$basePathApps/$app"
                $appObj = Get-Content $appPath | ConvertFrom-Json
                $appFile = $app -replace " ", "%20"
                
                $apiProductList = @()
                if ( $appObj.credentials.Count -ne 0 ) {
                    $apiProducts = $($appObj.credentials[0].apiProducts)
                    $apiProducts | ForEach-Object {
                        $apiProductList += $($_.apiproduct)
                    }
                    $apiProductListString = $apiProductList -join ", "

                    $appProducts = @{
                        app      = (($app -split "$org-" ) -split ".json" )[1]
                        products = $apiProductList
                    }
                    Write-Host
                    $appProductsList += $appProducts
                }
                
                $appsHeading = $appsHeading + " [$($appObj.name)](./$appFile) | $($appObj.status) | $apiProductListString `n"
                Write-Host "This is directory $app"
            }

            $appsBody = @"
 
App Name | Status | Products
 ---      | ---   | ---   
$appsHeading
 
"@

            Write-Host $appsBody
            $outAppsPath = "$basePathApps/README.MD"
            $appsBody | Out-File -FilePath $outAppsPath

            $appsNotesPath = "$basePath/readme/apps.MD"
            if ( Test-Path $appsNotesPath ) {
                $appsNotes = Get-Content $appsNotesPath
                $appsNotesHeader = @"
`n
# Notes
`n

"@
                Add-Content -Path $outAppsPath -Value $appsNotesHeader
                Write-Host $appsNotes
                Add-Content -Path $outAppsPath -Value $appsNotes
            }
        }

        elseif ( $artifact -eq "apiproducts" ) {
            $basePathProducts = "$basePath/$org/apiproducts"
            $productsHeading = ""
            $productProxiesList = @()

            Get-ChildItem $basePathProducts *.json | Foreach-Object {
                $product = Split-Path -Path $_.FullName -Leaf
                $productPath = "$basePathProducts/$product"
                $productObj = Get-Content $productPath | ConvertFrom-Json
                $productFile = $product -replace " ", "%20"

                $envList = $productObj.environments -join ", "
                $proxyList = $productObj.proxies -join ", "

                $productProxies = @{
                    product = ($product -split ".json" )[0]
                    proxies = $productObj.proxies
                }
                $productProxiesList += $productProxies
                
                $productsHeading = $productsHeading + " [$($productObj.name)](./$productFile) | $envList | $proxyList `n"
                Write-Host "This is directory $product"
            }

            $productsBody = @"
 
ApiProduct Name | Environments | Proxies
 ---      | ---   | ---   
$productsHeading
 
"@

            Write-Host $productsBody
            $outProductsPath = "$basePathProducts/README.MD"
            $productsBody | Out-File -FilePath $outProductsPath

            $productsNotesPath = "$basePath/readme/apiproducts.MD"
            if ( Test-Path $productsNotesPath ) {
                $productsNotes = Get-Content $productsNotesPath
                $productsNotesHeader = @"
`n
# Notes
`n

"@
                Add-Content -Path $outProductsPath -Value $productsNotesHeader
                Write-Host $productsNotes
                Add-Content -Path $outProductsPath -Value $productsNotes
            }
        }
        
        elseif ( $artifact -eq "developers" ) {
            $basePathDeveloper = "$basePath/$org/developers"
            $developersHeading = ""

            Get-ChildItem $basePathDeveloper *.json | Foreach-Object {
                $developer = Split-Path -Path $_.FullName -Leaf
                $developerPath = "$basePathDeveloper/$developer"
                $developerObj = Get-Content $developerPath | ConvertFrom-Json
                $developerFile = $developer -replace " ", "%20"
                
                $appsList = $developerObj.apps -join ", "
                
                $developersHeading = $developersHeading + "$($developerObj.firstName) | $($developerObj.lastName) | [$($developerObj.email)](./$developerFile) | $appsList `n"
                Write-Host "This is directory $developer"
            }

            $developersBody = @"
 
First Name | Last Name | Email | Apps
 ---      | ---   | ---        | ---
$developersHeading
 
"@

            Write-Host $developersBody
            $outDevelopersPath = "$basePathDeveloper/README.MD"
            $developersBody | Out-File -FilePath $outDevelopersPath

            $developersNotesPath = "$basePath/readme/developers.MD"
            if ( Test-Path $developersNotesPath ) {
                $developersNotes = Get-Content $developersNotesPath
                $developersNotesHeader = @"
`n
# Notes
`n

"@
                Add-Content -Path $outDevelopersPath -Value $developersNotesHeader
                Write-Host $developersNotes
                Add-Content -Path $outDevelopersPath -Value $developersNotes
            }
        }
       
        elseif ( $artifact -eq "environments" ) {
            $basePathEnvironments = "$basePath/$org/environments"
            $environmentsHeading = ""
            $environmentsList = @()

            Get-ChildItem $basePathEnvironments -Directory | Foreach-Object {
                $environmentName = Split-Path -Path $_.FullName -Leaf
                $environmentsList += $environmentName
                $environmentsHeading = $environmentsHeading + "## [$environmentName](./$environmentName/README.MD)`n"
                Write-Host "This is directory $environmentName"

            }

            $environmentsBody = @"
 
# Environments
$environmentsHeading
 
"@

            Write-Host $environmentsBody
            $outEnvironmentsPath = "$basePathEnvironments/README.MD"
            $environmentsBody | Out-File -FilePath $outEnvironmentsPath
        }
        
        elseif ( $artifact -eq "proxies" ) {
            $basePathProxies = "$basePath/$org/proxies"
            $proxiesHeading = ""
            
            Get-ChildItem $basePathProxies -Directory | Foreach-Object {
                $proxyRootDir = Split-Path -Path $_.FullName -Leaf
                $proxyRootDirPath = "$basePathProxies/$proxyRootDir"
                $proxyVersionsDir = Get-ChildItem $proxyRootDirPath -Directory | Sort-Object -Property { $_.Name -as [int] } -Descending
                
                $proxyVersionsDirList = @()
                $proxyVersionsDir | Foreach-Object {
                    $proxyVersionsDirList += Split-Path -Path $_.FullName -Leaf
                }
                
                $proxyTopVersionDir = "$proxyRootDirPath/$($proxyVersionsDirList[0])/$org-proxy-$proxyRootDir-rev$($proxyVersionsDirList[0])/apiproxy"
                $proxyTopVersionDirXML = "$proxyTopVersionDir/$proxyRootDir.xml"
                
                [xml]$proxyTopVersionContent = Get-Content $proxyTopVersionDirXML
                $proxyDesc = $proxyTopVersionContent.APIProxy.Description
                $proxyBasePaths = $proxyTopVersionContent.APIProxy.BasePaths
                $proxyPolicies = $proxyTopVersionContent.APIProxy.Policies.Policy
                $proxyPoliciesString = $proxyPolicies -join ", "
                $proxyResources = $proxyTopVersionContent.APIProxy.Resources.Resource
                $proxyResources = $proxyResources -join ", "
                
                $proxyProducts = @()
                $productProxiesList | Foreach-Object {
                    $proxyList = $_.proxies
                    if ( $proxyList -contains $proxyRootDir ) {
                        $proxyProducts += $_.product
                    }
                }
                $proxyProductsList = $proxyProducts -join ", "

                $proxyApps = @()
                $appProductsList | Foreach-Object {
                    $productsList = $_.products
                    $productApp = $_.app
                     
                    $proxyProducts | Foreach-Object {
                        $proxyProduct = $_
                        if ( $productsList -contains $proxyProduct ) {
                            $proxyApps += $productApp
                        }
                    }
                }
                $proxyAppsList = $proxyApps -join ", "
                
                $proxyPolicyResource = ""
                
                $proxyPolicyResource = $proxyPolicyResource + "$proxyPoliciesString | $proxyResources `n"
                Write-Host "This is directory $proxyRootDir"

                $proxyBody = @"
 
# $proxyRootDir - rev$($proxyVersionsDirList[0])
$proxyDesc

## Base-Path

$proxyBasePaths

Policies | Resources
--- | --- 
$proxyPolicyResource

## API Products
$proxyProductsList

## Apps
$proxyAppsList
 
"@
                Write-Host $proxyBody
                $outProxyPath = "$proxyRootDirPath/README.MD"
                $proxyBody | Out-File -FilePath $outProxyPath

                $proxyTopVersionTarget = "$proxyTopVersionDir/targets/default.xml"
                if ( Test-Path $proxyTopVersionTarget ) {
                    [xml]$proxyTopVersionTargetContent = Get-Content $proxyTopVersionTarget
                    $loadBalancer = $proxyTopVersionTargetContent.TargetEndpoint.HTTPTargetConnection.LoadBalancer
                    $targetUrl = $proxyTopVersionTargetContent.TargetEndpoint.HTTPTargetConnection.URL
                    
                    if ( $loadBalancer -ne $null ) {
                        if ( $loadBalancer.Server.Count -gt 0 ) {
                            $targetServerList = @()
                            $loadBalancer.Server | Foreach-Object {
                                $targetServerList += $_.name
                            }
                            $targetServerList = $targetServerList -join ", "
    
                            $targetServerListHeader = @"

## Target Servers
$targetServerList

"@
                            Add-Content -Path $outProxyPath -Value $targetServerListHeader
                        }
                    }
    
                    if ( $targetUrl -ne $null ) {
                        $targetUrlHeader = @"

## Target URL
$targetUrl

"@
                        Add-Content -Path $outProxyPath -Value $targetUrlHeader
                    }
                }
                
                $proxyTopVersionCache = "$proxyTopVersionDir/policies/ResponseCache.xml"
                if ( Test-Path $proxyTopVersionCache ) { 
                    [xml]$proxyTopVersionCacheContent = Get-Content $proxyTopVersionCache
                    $cacheResourceName = $proxyTopVersionCacheContent.ResponseCache.CacheResource

                    $cacheHeader = @"

## Cache Resource
$cacheResourceName

"@
                    Add-Content -Path $outProxyPath -Value $cacheHeader
                }
                
                $proxyNotesPath = "$basePath/readme/proxies/$proxyRootDir.MD"
                if ( Test-Path $proxyNotesPath ) {
                    $proxyNotes = Get-Content $proxyNotesPath
                    $notesHeader = @"
`n
# Notes
`n

"@
                    Add-Content -Path $outProxyPath -Value $notesHeader
                    Write-Host $proxyNotes
                    Add-Content -Path $outProxyPath -Value $proxyNotes
                }

                $versionHeading = ""
                $proxyVersionsDirList | Foreach-Object {
                    $version = $_
                    $proxyVersionDir = "$proxyRootDirPath/$version/$org-proxy-$proxyRootDir-rev$version/apiproxy"
                    $proxyVersionDirXML = "$proxyVersionDir/$proxyRootDir.xml"
                    
                    [xml]$proxyVersionContent = Get-Content $proxyVersionDirXML
                    $proxyVersionDesc = $proxyVersionContent.APIProxy.Description
                    $proxyVersionBasePaths = $proxyVersionContent.APIProxy.BasePaths
                    $proxyVersionPolicies = $proxyVersionContent.APIProxy.Policies.Policy
                    $proxyVersionPolicies = $proxyVersionPolicies -join ", "
                    $proxyVersionResources = $proxyVersionContent.APIProxy.Resources.Resource
                    $proxyVersionResources = $proxyVersionResources -join ", "

                    $proxyVersionPolicyResource = ""
                    $proxyVersionPolicyResource = $proxyVersionPolicyResource + "$proxyVersionPolicies | $proxyVersionResources `n"

                    $versionHeading = $versionHeading + "[$version](./$proxyRootDir/$version/README.MD) `t"

                    $proxyVersionBody = @"
 
# $proxyRootDir - rev$version
$proxyVersionDesc

## Base-Path

$proxyVersionBasePaths

Policies | Resources
--- | --- 
$proxyPolicyResource

"@
                    Write-Host $proxyVersionBody
                    $outProxyVersionPath = "$proxyRootDirPath/$version/README.MD"
                    $proxyVersionBody | Out-File -FilePath $outProxyVersionPath
                    
                }

                $proxiesHeading = $proxiesHeading + "[$proxyRootDir](./$proxyRootDir/README.MD) | $versionHeading `n"
                
            }

            $proxiesBody = @"
 
Name | Revision
 --- | --- |
$proxiesHeading
 
"@

            Write-Host $proxiesBody
            $outProxiesPath = "$basePathProxies/README.MD"
            $proxiesBody | Out-File -FilePath $outProxiesPath
        
        }
        
        elseif ( $artifact -eq "resources" ) {
            $basePathResources = "$basePath/$org/resources"
            $resourcesHeading = ""

            Get-ChildItem $basePathResources *.json | Foreach-Object {
                $resource = Split-Path -Path $_.FullName -Leaf
                $resourceFile = $resource -replace " ", "%20"
                $resourcesHeading = $resourcesHeading + "## [$resource](./$resourceFile)`n"
                Write-Host "This is directory $resource"
            }

            $resourcesBody = @"
 
# Resource Configurations
$resourcesHeading
 
"@

            Write-Host $resourcesBody
            $outResourcesPath = "$basePathResources/README.MD"
            $resourcesBody | Out-File -FilePath $outResourcesPath
        }

        elseif ( $artifact -eq "shared-flows" ) {
            $basePathSharedFlows = "$basePath/$org/shared-flows"
            $sharedFlowsHeading = ""

            Get-ChildItem $basePathSharedFlows -Directory | Foreach-Object {
                $sharedFlowRootDir = Split-Path -Path $_.FullName -Leaf
                $sharedFlowRootDirPath = "$basePathSharedFlows/$sharedFlowRootDir"
                $sharedFlowVersionsDir = Get-ChildItem $sharedFlowRootDirPath -Directory | Sort-Object -Property { $_.Name -as [int] } -Descending
                
                $sharedFlowVersionsDirList = @()
                $sharedFlowVersionsDir | Foreach-Object {
                    $sharedFlowVersionsDirList += Split-Path -Path $_.FullName -Leaf
                }
                
                $sharedFlowTopVersionDir = "$sharedFlowRootDirPath/$($sharedFlowVersionsDirList[0])/$org-sharedflows-$sharedFlowRootDir-rev$($sharedFlowVersionsDirList[0])/sharedflowbundle/$sharedFlowRootDir.xml"
                
                [xml]$sharedFlowTopVersionContent = Get-Content $sharedFlowTopVersionDir
                $sharedFlowDesc = $sharedFlowTopVersionContent.SharedFlowBundle.Description
                $sharedFlowPolicies = $sharedFlowTopVersionContent.SharedFlowBundle.Policies.Policy
                $sharedFlowPolicies = $sharedFlowPolicies -join ", "
                $sharedFlowResources = $sharedFlowTopVersionContent.SharedFlowBundle.Resources.Resource
                $sharedFlowResources = $sharedFlowResources -join ", "
                
                $sharedFlowPolicyResource = ""
                $sharedFlowPolicyResource = $sharedFlowPolicyResource + "$sharedFlowPolicies | $sharedFlowResources `n"
                Write-Host "This is directory $sharedFlowRootDir"

                $sharedFlowBody = @"
 
# $sharedFlowRootDir - rev$($sharedFlowVersionsDirList[0])
$sharedFlowDesc

Policies | Resources
--- | --- 
$sharedFlowPolicyResource
 
"@
                Write-Host $sharedFlowBody
                $outSharedFlowPath = "$sharedFlowRootDirPath/README.MD"
                $sharedFlowBody | Out-File -FilePath $outSharedFlowPath

                $sharedFlowNotesPath = "$basePath/readme/shared-flows/$sharedFlowRootDir.MD"
                if ( Test-Path $sharedFlowNotesPath ) {
                    $sharedFlowNotes = Get-Content $sharedFlowNotesPath
                    $notesHeader = @"
`n
# Notes
`n

"@
                    Add-Content -Path $outSharedFlowPath -Value $notesHeader
                    Write-Host $sharedFlowNotes
                    Add-Content -Path $outSharedFlowPath -Value $sharedFlowNotes
                }

                $sharedFlowVersionHeading = ""
                $sharedFlowVersionsDirList | Foreach-Object {
                    $sharedFlowVesion = $_
                    $sharedFlowVersionDir = "$sharedFlowRootDirPath/$sharedFlowVesion/$org-sharedflows-$sharedFlowRootDir-rev$sharedFlowVesion/sharedflowbundle/$sharedFlowRootDir.xml"
                    [xml]$sharedFlowVersionContent = Get-Content $sharedFlowVersionDir
                    $sharedFlowVersionDesc = $sharedFlowVersionContent.SharedFlowBundle.Description
                    $sharedFlowVersionPolicies = $sharedFlowVersionContent.SharedFlowBundle.Policies.Policy
                    $sharedFlowVersionPolicies = $sharedFlowVersionPolicies -join ", "
                    $sharedFlowVersionResources = $sharedFlowVersionContent.SharedFlowBundle.Resources.Resource
                    $sharedFlowVersionResources = $sharedFlowVersionResources -join ", "
                    
                    $sharedFlowVersionPolicyResource = ""
                    $sharedFlowVersionPolicyResource = $sharedFlowVersionPolicyResource + "$sharedFlowPolicies | $sharedFlowVersionResources `n"

                    $sharedFlowVersionHeading = $sharedFlowVersionHeading + "[$sharedFlowVesion](./$sharedFlowRootDir/$sharedFlowVesion/README.MD) `t"
                    
                    Write-Host "This is directory $sharedFlowRootDir - $sharedFlowVesion"
    
                    $sharedFlowVersionBody = @"
 
# $sharedFlowRootDir - rev$sharedFlowVesion
$sharedFlowVersionDesc

Policies | Resources
--- | --- 
$sharedFlowVersionPolicyResource
 
"@
                    Write-Host $sharedFlowVersionBody
                    $outSharedFlowVersionPath = "$sharedFlowRootDirPath/$sharedFlowVesion/README.MD"
                    $sharedFlowVersionBody | Out-File -FilePath $outSharedFlowVersionPath
                }

                $sharedFlowsHeading = $sharedFlowsHeading + "[$sharedFlowRootDir](./$sharedFlowRootDir/README.MD) | $sharedFlowVersionHeading `n"
                
            }

            $sharedFlowsBody = @"
 
Name | Revision
 --- | --- |
$sharedFlowsHeading
 
"@

            Write-Host $sharedFlowsBody
            $outSharedFlowsPath = "$basePathSharedFlows/README.MD"
            $sharedFlowsBody | Out-File -FilePath $outSharedFlowsPath
        
        }

        
    }

}



$orgList | ForEach-Object {
    $org = $_
       
    $environmentsList | ForEach-Object {
        $environment = $_
        $envExclusionList = @("aliases", "caches", "proxies", "shared-flows")
        $basePathEnvironments = "$basePath/$org/environments/$environment"
        $environmentHeading = ""
        
        Get-ChildItem $basePathEnvironments -Directory | ForEach-Object {
            $artifact = Split-Path -Path $_.FullName -Leaf

            if ( $envExclusionList -notcontains $artifact ) {
                $environmentHeading = $environmentHeading + "## [$artifact](./$artifact/README.MD)`n"
                Write-Host "This is directory $artifact"
            }
            
            if ( $artifact -eq "flowhooks" ) {
                $basePathFlowHooks = "$basePathEnvironments/flowhooks"
                $flowHooksHeading = ""

                Get-ChildItem $basePathFlowHooks *.json | Foreach-Object {
                    $flowHook = Split-Path -Path $_.FullName -Leaf
                    $flowHookPath = "$basePathFlowHooks/$flowHook"
                    $flowHookObj = Get-Content $flowHookPath | ConvertFrom-Json
                    $flowHookFile = $flowHook -replace " ", "%20"
                    
                    $flowHookName = ($flowHook -split ".json")[0]
                    
                    $flowHooksHeading = $flowHooksHeading + "[$flowHookName](./$flowHookFile) | $($flowHookObj.sharedFlow) `n"
                    Write-Host "This is directory $flowHookFile"
                }

                $flowHooksBody = @"
 
Name | Shared Flow 
 ---      | ---  
$flowHooksHeading
 
"@

                Write-Host $flowHooksBody
                $outFlowHooksPath = "$basePathFlowHooks/README.MD"
                $flowHooksBody | Out-File -FilePath $outFlowHooksPath
            }
            
            elseif ( $artifact -eq "keystores" ) {
                $basePathKeyStores = "$basePathEnvironments/keystores"
                $keyStoresHeading = ""

                Get-ChildItem $basePathKeyStores *.json | Foreach-Object {
                    $keyStore = Split-Path -Path $_.FullName -Leaf
                    $keyStorePath = "$basePathKeyStores/$keyStore"
                    $keyStoreObj = Get-Content $keyStorePath | ConvertFrom-Json
                    $keyStoreFile = $keyStore -replace " ", "%20"

                    $alisesList = @()
                    $keyStoreObj.aliases | ForEach-Object {
                        $alisesList += $_
                    }
                    $alisesList = $alisesList -join ", "
                
                    $keyStoresHeading = $keyStoresHeading + "[$($keyStoreObj.name)](./$keyStoreFile) | $alisesList `n"
                    Write-Host "This is directory $keyStore"
                }

                $keyStoresBody = @"
 
Name | Aliases
 ---      | --- 
$keyStoresHeading
 
"@

                Write-Host $keyStoresBody
                $outKeyStoresPath = "$basePathKeyStores/README.MD"
                $keyStoresBody | Out-File -FilePath $outKeyStoresPath
            
            }
            
            elseif ( $artifact -eq "kvms" ) {
                $basePathKVMs = "$basePathEnvironments/kvms"
                $kvmsHeading = ""

                Get-ChildItem $basePathKVMs *.json | Foreach-Object {
                    $kvm = Split-Path -Path $_.FullName -Leaf
                    $kvmPath = "$basePathKVMs/$kvm"
                    $kvmObj = Get-Content $kvmPath | ConvertFrom-Json
                    $kvmFile = $kvm -replace " ", "%20"
                    
                    if ( $kvmObj.PSobject.Properties.name -match "keyValueEntries") {
                        $kvmName = (($kvm -split "$org-$environment-") -split "-kvm-values.json")[1]
                        $kvmsHeading = $kvmsHeading + "[$kvmName](./$kvmFile) `n"
                        Write-Host "This is directory $kvm"
                    }
                }

                $kvmsBody = @"
 
Name  
 ---   | 
$kvmsHeading
 
"@

                Write-Host $kvmsBody
                $outKVMsPath = "$basePathKVMs/README.MD"
                $kvmsBody | Out-File -FilePath $outKVMsPath
            }
            
            elseif ( $artifact -eq "resources" ) {
                $basePathResources = "$basePathEnvironments/resources"
                $resourcesHeading = ""

                Get-ChildItem $basePathResources *.json | Foreach-Object {
                    $resource = Split-Path -Path $_.FullName -Leaf
                    $resourceFile = $resource -replace " ", "%20"
                    $resourcesHeading = $resourcesHeading + "## [$resource](./$resourceFile)`n"
                    Write-Host "This is directory $resource"
                }

                $resourcesBody = @"
 
# Resource Configurations
$resourcesHeading
 
"@

                Write-Host $resourcesBody
                $outResourcesPath = "$basePathResources/README.MD"
                $resourcesBody | Out-File -FilePath $outResourcesPath
            }
            
            elseif ( $artifact -eq "target-servers" ) {
                $basePathTargetServers = "$basePathEnvironments/target-servers"
                $targetServersHeading = ""

                Get-ChildItem $basePathTargetServers *.json | Foreach-Object {
                    $targetServer = Split-Path -Path $_.FullName -Leaf
                    $targetServerPath = "$basePathTargetServers/$targetServer"
                    $targetServerObj = Get-Content $targetServerPath | ConvertFrom-Json
                    $targetServerFile = $targetServer -replace " ", "%20"
                    
                    $targetServersHeading = $targetServersHeading + "[$($targetServerObj.name)](./$targetServerFile) | $($targetServerObj.host) | $($targetServerObj.port) | $($targetServerObj.isEnabled) `n"
                    Write-Host "This is directory $targetServer"
                }

                $targetServersBody = @"
 
Name | Host Name | Port | IsEnabled
 ---      | ---   | ---        | ---
$targetServersHeading
 
"@

                Write-Host $targetServersBody
                $outTargetServersPath = "$basePathTargetServers/README.MD"
                $targetServersBody | Out-File -FilePath $outTargetServersPath
            }
        }

        $envBody = @"
 
# Environment Artifact Configurations
$environmentHeading
 
"@

        Write-Host $envBody
        $outEnvPath = "$basePathEnvironments/README.MD"
        $envBody | Out-File -FilePath $outEnvPath
    }
}
