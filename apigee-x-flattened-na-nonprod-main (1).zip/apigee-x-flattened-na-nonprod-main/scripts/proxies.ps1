# Input parameters

Param (
    [Parameter(mandatory = $true)][string]$accessToken, # To receive GCP access token
    [Parameter(mandatory = $true)][string]$org, # To receive Apigee Organization where action will be performed      
    [Parameter(mandatory = $true)][string]$action, # To receive type of action script shall perform
    [Parameter(mandatory = $false)][string]$env, # To receive environment where proxy will be deployed
    [Parameter(mandatory = $false)][string]$proxyname, # To receive proxy name  
    [Parameter(mandatory = $false)][string]$XProxyversion, # To receive Apigee X proxy version which will be deployed
    [Parameter(mandatory = $false)][string]$edgeProxyversion # To receive Apigee edge proxy version which will be imported
)

# Load utility functions
. "$PSScriptRoot\utilities.ps1"

# Set Variables 

$headers = @{Authorization = "Bearer $accessToken " }
$sourceOrgFolder = Get-SourceOrg -targetOrg $org  #call utility function from utilities script
$proxyDirectory = "$sourceOrgFolder/proxies"
$currentDir = Get-Location
$apigeeDomain = "https://apigee.googleapis.com/v1/organizations/$org"

# Different actions

if ($action -eq "ImportProxyVersion") {
    
    Write-Host "Start ImportProxyVersion for proxy $proxyname & version $edgeProxyversion"
    Set-Location $proxyDirectory
    $currentdir = Get-Location
    $proxyVersionFolder = "$currentdir/$proxyname/$edgeProxyversion"

    if ($proxyname -ne 'null' -AND $edgeProxyversion -ne 'null' -AND (Test-Path $proxyVersionFolder )) {
        
        Set-Location $proxyVersionFolder
        $zipFile = Get-ChildItem *.zip
        $requestFile = @{file = Get-Item -Path $zipFile }
        $uri = "$apigeeDomain/apis?action=import&name=$proxyname&validate=true"
        Invoke-WebRequest  -Uri $uri -Method Post -Form $requestFile -Headers $headers
        Write-Host "End ImportProxyVersion for proxy $proxyname & version $edgeProxyversion"
    }
    else {
        Write-Error "Error ImportProxyVersion for proxy $proxyname & version $edgeProxyversion : Invalid proxy or version"
    }
}
elseif ($action -eq "ImportTop5ProxyVersion") {
    
    Write-Host "Start ImportTop5ProxyVersion for proxy $proxyname"
    Set-Location $proxyDirectory
    $currentdir = Get-Location
    $proxyfolder = "$currentdir\$proxyname"
    if ($proxyname -ne 'null' -AND (Test-Path $proxyfolder )) {   
        $currentdir = Get-Location
        Set-Location $proxyfolder
        $versionList = Get-ChildItem -Directory | Sort-Object -Property { $_.Name -as [int] } -Descending
        $versionCount = (Get-ChildItem | Measure-Object).count
        Write-Host "Total $versionCount in folder  $proxyfolder" 
        
        if ($versionCount -ge 5) {
            $loopCount = 5 
        }
        else { $loopCount = $versionCount }

        for ($i = $loopCount - 1 ; $i -ge 0 ; $i--) {
            
            $versionFolder = $versionList[$i]
            Set-Location $versionFolder
            $zipFile = ls *.zip
            Write-Host "Zip file name $zipFile"
            $requestFile = @{file = Get-Item -Path $zipFile }
            $uri = "$apigeeDomain/apis?action=import&name=$proxyname&validate=true"
            Invoke-WebRequest  -Uri $uri -Method Post -Form $requestFile -Headers $headers
            Write-Host "Imported Zip file  $zipFile"
            Set-Location ..
             
        } 
        
    }
    else {
        Write-Error "Error ImportTop5ProxyVersion for proxy $proxyname : Invalid proxy or version"
    }

    Write-Host "End ImportTop5ProxyVersion for proxy $proxyname"
}
elseif ($action -eq "DeleteProxyVersion") {
        Write-Host "Start DeleteProxyVersion for proxy $proxyname & version $XProxyversion"
   if ($proxyname -ne 'null' -AND $XProxyversion -ne 'null') {
        $uri = "$apigeeDomain/apis/$proxyname/revisions/$XProxyversion"
        Invoke-WebRequest  -Uri $uri -Method Delete -Headers $headers
      }
   else
       {
        Write-Error "Error DeleteProxyVersion for proxy $proxyname and version $XProxyversion : Invalid proxy or version"
       }
        Write-Host "End DeleteProxyVersion for proxy $proxyname and version $XProxyversion"
}
elseif ($action -eq "DeleteProxy") {
    Write-Host "Start DeleteProxy for proxy $proxyname"
   if ($proxyname -ne 'null') {
        $uri = "$apigeeDomain/apis/$proxyname"
        Invoke-WebRequest  -Uri $uri -Method Delete -Headers $headers
      }
   else
       {
        Write-Error "Error DeleteProxy for proxy $proxyname  : Invalid proxy name"
       }
        Write-Host "End DeleteProxy for proxy $proxyname"
}
elseif ($action -eq "Deploy") {
   
    Write-Host "Start Deploy for proxy $proxyname & version $XProxyversion"
    Set-Location $proxyDirectory
    $currentdir = Get-Location
    $proxyVersionFolder = "$currentdir\$proxyname\$XProxyversion"
    if ($proxyname -ne 'null' -AND $XProxyversion -ne 'null' -AND (Test-Path $proxyVersionFolder )) {

        Set-Location $proxyVersionFolder
        $uri = "$apigeeDomain/environments/$env/apis/$proxyname/revisions/$XProxyversion/deployments?override=true&sequencedRollout=true"
        Invoke-WebRequest  -Uri $uri -Method Post -ContentType 'application/json; charset=utf-8' -Headers $headers
    }
    else {
        Write-Error "End Deploy for proxy $proxyname & version $XProxyversion : Invalid proxy or version"
    }
    Write-Host "End Deploy for proxy $proxyname & version $XProxyversion"
}
elseif ($action -eq "Undeploy") {
       
     Write-Host "Start Undeploy for proxy $proxyname & version $XProxyversion"
    if ($proxyname -ne 'null' -AND $XProxyversion -ne 'null') {
    $uri = "$apigeeDomain/environments/$env/apis/$proxyname/revisions/$XProxyversion/deployments?sequencedRollout=true"
    Invoke-WebRequest  -Uri $uri -Method Delete -ContentType 'application/json; charset=utf-8' -Headers $headers
     } else {
        Write-Error "Error Undeploy for proxy $proxyname & version $XProxyversion : Invalid proxy or version"
     }
     Write-Host "End  Undeploy for proxy $proxyname & version $XProxyversion"
}
elseif ($action -eq "ImportAndDeployProxy") {
       
    Write-Host "Start ImportAndDeployProxy for proxy $proxyname & version $edgeProxyversion"
    Set-Location $proxyDirectory
    $currentdir = Get-Location
    $proxyVersionFolder = "$currentdir/$proxyname/$edgeProxyversion"

    if ($proxyname -ne 'null' -AND $edgeProxyversion -ne 'null' -AND $env -ne 'null' -AND (Test-Path $proxyVersionFolder )) {
        
        Set-Location $proxyVersionFolder
        $zipFile = Get-ChildItem *.zip
        $requestFile = @{file = Get-Item -Path $zipFile }
        $uri = "$apigeeDomain/apis?action=import&name=$proxyname&validate=true"
        $importResponse = Invoke-WebRequest  -Uri $uri -Method Post -Form $requestFile -Headers $headers
        if ($importResponse.statuscode -eq '200') {
             $revision = ConvertFrom-Json $importResponse.Content | Select-Object -expand "revision"
             Write-Host = "Proxy imported with version $revision,deploying to $env " 
           
             $uri = "$apigeeDomain/environments/$env/apis/$proxyname/revisions/$revision/deployments?override=true&sequencedRollout=true"
             try {
               Invoke-WebRequest  -Uri $uri -Method Post -ContentType 'application/json; charset=utf-8' -Headers $headers
              } catch {
              
               Write-Host  "Got following exception while deploying proxy, deleting it."
               Write-Host  $_.Exception.Message
               $uri = "$apigeeDomain/apis/$proxyname/revisions/$revision"
               Invoke-WebRequest  -Uri $uri -Method Delete -Headers $headers
               Exit 1
              }
        Write-Host "End ImportAndDeployProxy for proxy $proxyname , version $edgeProxyversion"
    }else{
        Write-Error "Error ImportProxyVersion for proxy $proxyname , version $edgeProxyversion : Import failed"
        Write-Error $_.Exception.Message}
        }
    else {
        Write-Error "Error ImportProxyVersion for proxy $proxyname , version $edgeProxyversion : Invalid proxy or version or env"
    }
}
elseif ($action -eq "ImportAllProxyVersions") {

    Write-Host "Start ImportAllProxyVersions for proxy $proxyname"
    Set-Location $proxyDirectory
    $currentdir = Get-Location
    $proxyfolder = "$currentdir\$proxyname"
    if ($proxyname -ne 'null' -AND (Test-Path $proxyfolder )) {   
        $currentdir = Get-Location
        Set-Location $proxyfolder
        $versionList = Get-ChildItem -Directory | Sort-Object -Property { $_.Name -as [int] } -Descending
        [Array]::Reverse($versionList)
        Write-Host "Total $($versionList.Count) in folder  $proxyfolder" 
        
        $versionList | ForEach-Object {
            
            $versionFolder = $_
            Set-Location $versionFolder
            $zipFile = ls *.zip
            Write-Host "Zip file name $zipFile"
            $requestFile = @{file = Get-Item -Path $zipFile }
            $uri = "$apigeeDomain/apis?action=import&name=$proxyname&validate=true"
            Invoke-WebRequest  -Uri $uri -Method Post -Form $requestFile -Headers $headers
            Write-Host "Imported Zip file  $zipFile"
            Set-Location ..
             
        } 
        
    }
    else {
        Write-Error "Error ImportAllProxyVersions for proxy $proxyname : Invalid proxy or version"
    }

    Write-Host "End ImportAllProxyVersions for proxy $proxyname"
    
}
elseif ($action -eq "DeployAllProxies") {

        if( $env -ne "null" ){
        $proxyEnvDirectory = "$currentDir/$sourceOrgFolder/environments/$env/proxies"
        
        Get-ChildItem $proxyEnvDirectory -Directory | ForEach-Object {
            $proxyName = Split-Path -Path $_.FullName -Leaf
            $proxyPath = "$proxyEnvDirectory/$proxyName"
            $proxyDeployVersion = Split-Path -Path (Get-ChildItem $proxyPath -Directory ).FullName -Leaf        
            Write-Host "Deploying Proxy $proxyName and Revision $proxyDeployVersion to $env"
            
            $uri = "$apigeeDomain/environments/$env/apis/$proxyName/revisions/$proxyDeployVersion/deployments?override=true&sequencedRollout=true"
            try {
                Invoke-WebRequest  -Uri $uri -Method Post -ContentType 'application/json; charset=utf-8' -Headers $headers
            }
            catch {
                Write-Host "An error occurred while deploying $proxyName : $_"
            }
        }
    }
    else {
        Write-Error "Error DeployAllProxies : Invalid env"
    }
}
else {
    Write-Error "No valid input...skipping script."
}
