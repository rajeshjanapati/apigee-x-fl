Param (
    [Parameter(mandatory = $true)][string]$AccessToken, # To receive GCP access token
    [Parameter(mandatory = $true)][string]$Org, # To receive Apigee Organization where action will be performed      
    [Parameter(mandatory = $true)][string]$Action, # To receive type of action script shall perform
    [Parameter(mandatory = $true)][string]$SourceEnv, # To receive Environment from where to take Resource data from repo
    [Parameter(mandatory = $true)][string]$TargetEnv, # To receive Environment where Resource will be deployed
    [Parameter(mandatory = $false)][string]$ResourceName, # To receive Resource name
    [Parameter(mandatory = $false)][string]$ResourceType, # To receive Resource Type for Adhoc JSON Create or Update Action
    [Parameter(mandatory = $false)][string]$ResourceBytes  # To receive Resource file as Base64 string
)

# Load utility functions
. "$PSScriptRoot\utilities.ps1"

# Set Variables 
$headers = @{Authorization = "Bearer $AccessToken" }
if ( $Action -ne "Delete") {
    $sourceOrg = Get-SourceOrg -targetOrg $Org  #call utility function from utilities script
    $resourceDirectory = "./$sourceOrg/environments/$SourceEnv/resources"
    Set-Location $resourceDirectory
    $files = Get-ChildItem -Exclude *.md,*.MD
}
$apigeeDomain = "https://apigee.googleapis.com/v1/organizations/$Org/environments/$TargetEnv/resourcefiles"

$resourceNameValid = ![string]::IsNullOrEmpty($ResourceName) -And ![string]::IsNullOrWhitespace($ResourceName) -And $ResourceName -ne "null"
$resourceTypeValid = ![string]::IsNullOrEmpty($ResourceType) -And ![string]::IsNullOrWhitespace($ResourceType) -And $ResourceType -ne "null"
$resourceBytesValid = ![string]::IsNullOrEmpty($ResourceBytes) -And ![string]::IsNullOrWhitespace($ResourceBytes) -And $ResourceBytes -ne "null"

if ( $Action -eq "ImportAll" ) {
    Write-Host "Importing Resources"
    $successCount = 0
    $failureCount = 0
    $failedResourceName = @()
    foreach ($file in $files ) {
        $fileName = (Get-Item $file ).Name
        $currentDir = Get-Location
        $filePath = "$currentDir/$fileName"
        Write-Host "FilePath:- $filePath"
        $type = (Get-Item $filePath ).Extension.Split(".")[1]
	
        $param = "?name=$fileName&type=$type"
        Write-Host "Params:- $param"
	
        $uri = "$apigeeDomain$param"
        Write-Host "URI $uri"
        
        try { 
            Invoke-WebRequest -Uri $uri -Method POST -InFile $filePath -ContentType "application/octet-stream" -Headers $headers
            $successCount++
        }
        catch {
            # Handle any other exceptions that may occur
            Write-Host "An error occurred while importing Resource $fileName : $_"
            $failureCount++
            $failedResourceName += $fileName
        }
    }
    $summary = "Resources Import All:- Total $($successCount + $failureCount) Succeeded $successCount Failed $failureCount. Failed Resource Names $($failedResourceName -join ",")"
    if ( $failureCount -gt 0 ) {
        Write-Error $summary
    }
    else {
        Write-Host $summary
    }
}
elseif ( $Action -eq "Create" -And !$resourceBytesValid ) {
    if ( $resourceNameValid ) { 
        $currentDir = Get-Location
        $filePath = "$currentDir/$ResourceName"
        Write-Host "FilePath:- $filePath"
        if ( Test-Path $filePath ) {
            Write-Host "Creating Resource with name $ResourceName"
		 
            $type = (Get-Item $filePath ).Extension.Split(".")[1]
			
            $param = "?name=$ResourceName&type=$type"
            Write-Host "Params:- $param"
		
            $uri = "$apigeeDomain$param"
		  
            Invoke-WebRequest -Uri $uri -Method POST -InFile $filePath -ContentType "application/octet-stream" -Headers $headers
        }
        else {
            Write-Error "$ResourceName file doesnot exist at path $filePath"
        }
    }
    else {
        Write-Error "Resource Name Required For Create Action"
   	}
}
elseif ( $Action -eq "Update" -And !$resourceBytesValid) {
    if ( $resourceNameValid ) { 
        $currentDir = Get-Location
        $filePath = "$currentDir/$ResourceName"
        Write-Host "FilePath:- $filePath"
        if ( Test-Path $filePath ) {
            Write-Host "Updating Resource with name $ResourceName"
		
            $type = (Get-Item $filePath ).Extension.Split(".")[1]
				
            $param = "/$type/$ResourceName"
            Write-Host "Params:- $param"
				
            $uri = "$apigeeDomain$param"
		
            Invoke-WebRequest -Uri $uri -Method PUT -InFile $filePath -ContentType "application/octet-stream" -Headers $headers
        } 
        else {
            Write-Error "$ResourceName file doesnot exist at path $filePath"
        }
    }
    else {
        Write-Error "Resource Name Required For Update Action"
   	}
}
elseif ( $Action -eq "Delete" ) {
    if ( $resourceNameValid ) { 
        Write-Host "Deleting Resource with name $ResourceName"
  
        $type = $ResourceName.Split(".")[1]
	  
        $param = "/$type/$ResourceName"
        Write-Host "Params:- $param"
	  
        $uri = "$apigeeDomain$param"
  	
        Invoke-WebRequest -Uri $uri -Method DELETE -ContentType 'application/json; charset=utf-8' -Headers $headers
    }
    else {
        Write-Error "Resource Name Required For Delete Action"
   	}
}
elseif ( ( $Action -eq "Create" -Or $Action -eq "Update" ) -And $resourceBytesValid ) {
    if ( $Action -eq "Create" ) {
        if ( $resourceNameValid ) { 
            Write-Host "Creating resource with Adhoc JSON resource $ResourceName and type $ResourceType"
	
            $currentdir = Get-Location
            $filePath = "$currentdir/$ResourceName"
   
            $bytes = [Convert]::FromBase64String($ResourceBytes)
            [IO.File]::WriteAllBytes($filePath, $bytes)
			
            Write-Host "FilePath:- $filePath"
			
            $param = "?name=$ResourceName&type=$ResourceType"
            Write-Host "Params:- $param"
		
            $uri = "$apigeeDomain$param"
		  
            Invoke-WebRequest -Uri $uri -Method POST -InFile $filePath -ContentType "application/octet-stream" -Headers $headers
        } 
        else {
            Write-Error "Resource Name Required For Create Action"
        }
    }
    elseif ( $Action -eq "Update" ) {
        if ( $resourceNameValid ) { 
            Write-Host "Updating resource with Adhoc JSON resource $ResourceName and type $ResourceType"
	
            $currentdir = Get-Location
            $filePath = "$currentdir/$ResourceName"
	   
            $bytes = [Convert]::FromBase64String($ResourceBytes)
            [IO.File]::WriteAllBytes($filePath, $bytes)

            Write-Host "FilePath:- $filePath"
			
            $param = "/$ResourceType/$ResourceName"
            Write-Host "Params:- $param"
			
            $uri = "$apigeeDomain$param"
	
            Invoke-WebRequest -Uri $uri -Method PUT -InFile $filePath -ContentType "application/octet-stream" -Headers $headers
        } 
        else {
            Write-Error "Resource Name Required For Update Action"
        }
    }
}
else {
    Write-Error "Invalid Action"
}
