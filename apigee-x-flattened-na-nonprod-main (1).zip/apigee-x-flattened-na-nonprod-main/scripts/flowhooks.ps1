# Input parameters

Param (
    [Parameter(mandatory = $true)][string]$accessToken, # To receive GCP access token
    [Parameter(mandatory = $true)][string]$org, # To receive Apigee Organization where action will be performed      
    [Parameter(mandatory = $true)][string]$action, # To receive type of action script shall perform
    [Parameter(mandatory = $false)][string]$targetEnv, # To receive environment where flowhook will be imported
    [Parameter(mandatory = $false)][string]$sourceEnv, # To receive environment from where flowhook will be exported  
    [Parameter(mandatory = $false)][string]$flowhooktype, # To receive Webhook type which will be associated with sharedflow
    [Parameter(mandatory = $false)][string]$adhocRequest # To receive Shared flow name
)


# Load utility functions
. "$PSScriptRoot\utilities.ps1"

# Set Variables 

$headers = @{Authorization = "Bearer $accessToken " }
$sourceOrgFolder = Get-SourceOrg -targetOrg $org  #call utility function from utilities script
$flowhooksDirectory = "$sourceOrgFolder/environments"
$headers = @{Authorization = "Bearer $accessToken " }
$apigeeDomain = "https://apigee.googleapis.com/v1/organizations/$org"


if ($action -eq "ImportAll") {

Write-Host "Start ImportFlowhook into target $targetEnv from source env $sourceEnv"
    Set-Location $flowhooksDirectory/$sourceEnv/flowhooks
    $flowhookFiles = Get-ChildItem *.json
    foreach ($file in $flowhookFiles ) {
		$fileContent = Get-Content $file | ConvertFrom-Json
                 $json_body =  Get-Content $file

    $Uri = "$apigeeDomain/environments/$targetEnv/flowhooks/$($fileContent.flowHookPoint)"
    Write-Host $json_body
    $sharedflow = $fileContent.sharedFlow
    
   if ($sharedflow -eq $null)
    {
     Write-Host Detach flowhook
    Invoke-WebRequest  -Uri $Uri -Method DELETE -Headers $headers}
    else
    {
    Write-Host Attach flowhook
    Invoke-WebRequest  -Uri $Uri -Method Put -Body $json_body -Headers $headers}
   
    Write-Host "End ImportFlowhook into target $targetEnv from source env $sourceEnv"
}}


elseif ($action -eq "ImportFlowhookFile") {

Write-Host "Start ImportFlowhookFile into target $targetEnv from source env $sourceEnv"
    Set-Location $flowhooksDirectory/$sourceEnv/flowhooks
    $flowhookFile = Get-ChildItem $flowhooktype*
    $fileContent = Get-Content $flowhookFile | ConvertFrom-Json        
    $json_body = Get-Content $flowhookFile
    $Uri = "$apigeeDomain/environments/$targetEnv/flowhooks/$($fileContent.flowHookPoint)"
    $sharedflow = $fileContent.sharedFlow
    
   if ($sharedflow -eq $null)
    {
     Write-Host Detach flowhook
    Invoke-WebRequest  -Uri $Uri -Method DELETE -Headers $headers}
    else
    {
    Write-Host Attach flowhook
    Invoke-WebRequest  -Uri $Uri -Method Put -Body $json_body -Headers $headers}
   
    Write-Host "End ImportFlowhookFile into target $targetEnv from source env $sourceEnv"
}
   

elseif ($action -eq "ImportFlowhookAdhoc") {

    Write-Host "Start ImportFlowhookAdhoc into target $targetEnv from adhoc request"    
    $adhocRequestObj = $adhocRequest| ConvertFrom-Json | ConvertFrom-Json
    $sharedFlow = $adhocRequestObj.sharedFlow
    $flowHookPoint = $adhocRequestObj.flowHookPoint
    $Uri = "$apigeeDomain/environments/$targetEnv/flowhooks/$flowHookPoint"
    
      
   if ($sharedflow -eq $null -OR $sharedflow -eq "")
    {
     Write-Host Detach flowhook  $adhocRequestObj
    Invoke-WebRequest  -Uri $Uri -Method DELETE -Headers $headers}
    else
    {
    $apiPayload = $adhocRequest| ConvertFrom-Json
    Write-Host "Attach flowhook using request $apiPayload"
    Invoke-WebRequest  -Uri $Uri -Method Put -Body $apiPayload -Headers $headers
    }
    Write-Host "End ImportFlowhookAdhoc into target $targetEnv from adhoc request"
    }

else {
    Write-Error "No valid input...skipping script."
}
