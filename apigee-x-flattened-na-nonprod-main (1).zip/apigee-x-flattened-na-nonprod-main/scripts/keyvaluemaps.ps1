Param (
    [Parameter(mandatory = $true)][string]$AccessToken, # To receive GCP access token
    [Parameter(mandatory = $true)][string]$Org, # To receive Apigee Organization where action will be performed      
    [Parameter(mandatory = $true)][string]$Action, # To receive type of action script shall perform
    [Parameter(mandatory = $true)][string]$SourceEnv, # To receive environment from where to take KVM data from repo
    [Parameter(mandatory = $true)][string]$TargetEnv, # To receive environment where KVM will be deployed
    [Parameter(mandatory = $false)][string]$KVMName, # To receive KVM Name
    [Parameter(mandatory = $false)][string]$KVMKey, # To receive KVM Key
    [Parameter(mandatory = $false)][string]$KVMJsonBody # To receive KVM Adhoc JSON Body
)

# Load utility functions
. "$PSScriptRoot\utilities.ps1"

# Set Variables 

$headers = @{Authorization = "Bearer $AccessToken" }

if ( $action -ne "Delete") {
    $sourceOrg = Get-SourceOrg -targetOrg $Org  #call utility function from utilities script
    $kvmDirectory = "./$sourceOrg/environments/$SourceEnv/kvms"
    Set-Location $kvmDirectory
    $files = Get-ChildItem *.json
}

$apigeeDomain = "https://apigee.googleapis.com/v1/organizations/$Org/environments/$TargetEnv/keyvaluemaps"
$kvmNameValid = ![string]::IsNullOrEmpty($KVMName) -And ![string]::IsNullOrWhitespace($KVMName) -And $KVMName -ne "null"
$kvmKeyValid = ![string]::IsNullOrEmpty($KVMKey) -And ![string]::IsNullOrWhitespace($KVMKey) -And $KVMKey -ne "null"
$kvmJsonBodyValid = ![string]::IsNullOrEmpty($KVMJsonBody) -And ![string]::IsNullOrWhitespace($KVMJsonBody) -And $KVMJsonBody -ne "null"

if ( $Action -eq "ImportAll" ) {
    Write-Host "Importing ALL KVMs" 
    $successCount = 0
    $failureCount = 0
    $alreadyExistKVMCount = 0
    $successEntriesCount = 0
    $failureEntriesCount = 0
    $failedKVMName = @()
    $failedKVMEntryName = @()

    $existingKVMList = Invoke-WebRequest -Uri $apigeeDomain -Method 'GET' -ContentType 'application/json; charset=utf-8' -Headers $headers
    $existingKVMList = $existingKVMList | ConvertFrom-Json
    Write-Host "Existing KVM List $existingKVMList"

    foreach ($file in $files) {
        $requestPayload = Get-Content $file | ConvertFrom-Json
        if ( $requestPayload.PSobject.Properties.name -match "keyValueEntries") {
            $name = (($file -split "$sourceOrg-$SourceEnv-") -split "-kvm-values.json")[1]
            
            if ( $existingKVMList -notcontains $name) {       
                Write-Host "Creating KVM $name"
    
                $reqObject = [PSCustomObject]@{
                    encrypted = $($requestPayload.encrypted)
                    name      = "$name"
                }
    
                $reqPayload = $reqObject | ConvertTo-Json
    
                Write-Host "KVM Request Payload:- $reqPayload"
    
                try { 
                    Invoke-WebRequest -Uri $apigeeDomain -Method 'POST' -ContentType 'application/json; charset=utf-8' -Body $reqPayload -Headers $headers
                    $successCount++
                }
                catch {
                    # Handle any other exceptions that may occur
                    Write-Host "An error occurred while importing KVM $name : $_"
                    $failureCount++
                    $failedKVMName += $name
                }
            }
            else {
                Write-Host "KVM $name already exists"
                $alreadyExistKVMCount++
            }

            $entries = $requestPayload.keyValueEntries

            foreach ($entry in $entries) {
                Write-Host "Importing entry $($entry.name) in KVM $name"

                $key = $env:AES_KEY
                $encryptedValue = $entry.value
                if( $encryptedValue -ne $null ) {
                    $decryptedValue = Decrypt-String -encryptedStringWithIV $encryptedValue -key $key
                } 

                $entryReqObject = [PSCustomObject]@{
                    name  = $($entry.name)
                    value = $decryptedValue
                }

                $entryReqPayload = $entryReqObject | ConvertTo-Json

                $uri = "$apigeeDomain/$name/entries"
                try { 
                    $response = Invoke-WebRequest -Uri $uri -Method 'POST' -ContentType 'application/json; charset=utf-8' -Body $entryReqPayload -Headers $headers
                    $successEntriesCount++
                }
                catch {
                    # Handle any other exceptions that may occur
                    Write-Host "An error occurred while importing KVM Entry $($entry.name) : $_"
                    $failureEntriesCount++
                    $failedKVMEntryName += "$name - $($entry.name)"
                }

            }

        }
    }
    $summary = "KVMs Import All:- Total $($successCount + $failureCount + $alreadyExistKVMCount) Succeeded $successCount Failed $failureCount AlreadyExist $alreadyExistKVMCount. Failed KVM Names $($failedKVMName -join ",") . KVM Entries Import All:- Total $($successEntriesCount + $failureEntriesCount) Succeeded $successEntriesCount Failed $failureEntriesCount. Failed KVM Entry Names $($failedKVMEntryName -join ",") "
    if ( $failureCount -gt 0 -Or $failureEntriesCount -gt 0 ) {
        Write-Error $summary
    }
    else {
        Write-Host $summary
    }
}
elseif ( $Action -eq "Create" -And !$kvmJsonBodyValid ) {
    if ( $kvmNameValid ) {
        foreach ($file in $files) {
            $requestPayload = Get-Content $file | ConvertFrom-Json
            if ( $requestPayload.PSobject.Properties.name -match "keyValueEntries") {
                $name = (($file -split "$sourceOrg-$SourceEnv-") -split "-kvm-values.json")[1]
                if ( $name -eq $KVMName ) {
                    Write-Host "Trying to Delete existing KVM $name"

                    $uri = "$apigeeDomain/$name"
                    try { 
                        Invoke-WebRequest -Uri $uri -Method 'DELETE' -ContentType 'application/json; charset=utf-8' -Headers $headers
                    }
                    catch {
                        # Handle any other exceptions that may occur
                        Write-Host "An error occurred: $_"
                    }

                    Write-Host "Creating KVM $name"

                    $reqObject = [PSCustomObject]@{
                        encrypted = $false
                        name      = "$name"
                    }

                    $reqPayload = $reqObject | ConvertTo-Json

                    Write-Host "KVM Request Payload:- $reqPayload"
 
                    Invoke-WebRequest -Uri $apigeeDomain -Method 'POST' -ContentType 'application/json; charset=utf-8' -Body $reqPayload -Headers $headers

                    $entries = $requestPayload.keyValueEntries

                    foreach ($entry in $entries) {
                        Write-Host "Importing entry $($entry.name) in KVM $name"

                        $key = $env:AES_KEY
                        $encryptedValue = $entry.value
                        if( $encryptedValue -ne $null ) {
                            $decryptedValue = Decrypt-String -encryptedStringWithIV $encryptedValue -key $key
                        } 

                        $entryReqObject = [PSCustomObject]@{
                            name  = $($entry.name)
                            value = $decryptedValue
                        }

                        $entryReqPayload = $entryReqObject | ConvertTo-Json

                        $uri = "$apigeeDomain/$name/entries"
                         
                        $response = Invoke-WebRequest -Uri $uri -Method 'POST' -ContentType 'application/json; charset=utf-8' -Body $entryReqPayload -Headers $headers
                    }
                }
            }
        }
    }
    else {
        Write-Error "KVM Name Required For Create Action"
   	}    
}
elseif ( $Action -eq "Delete" -And !$kvmKeyValid ) {
    if ( $kvmNameValid ) {
        Write-Host " Delete KVM $KVMName"

        $uri = "$apigeeDomain/$KVMName"
         
        Invoke-WebRequest -Uri $uri -Method 'DELETE' -ContentType 'application/json; charset=utf-8' -Headers $headers
    }
    else {
        Write-Error "KVM Name Required Delete KVM Action"
   	}
}
elseif ( $Action -eq "Delete" -And $kvmKeyValid ) {
    if ( $kvmNameValid ) {
        Write-Host " Delete KVM Entry $KVMKey from KVM $KVMName"

        $uri = "$apigeeDomain/$KVMName/entries/$KVMKey"
         
        $response = Invoke-WebRequest -Uri $uri -Method 'DELETE' -ContentType 'application/json; charset=utf-8' -Headers $headers
    }
    else {
        Write-Error "KVM Name and KVMKey Delete KVMKey Action"
   	}
}
elseif ( $Action -eq "Create" -And $kvmJsonBodyValid -And !$kvmNameValid) {
    $requestPayload = $KVMJsonBody | ConvertFrom-Json | ConvertFrom-Json
    
    Write-Host "Creating KVM $($requestPayload.name)"

    $reqPayload = $requestPayload | ConvertTo-Json

    Write-Host "KVM Request Payload:- $reqPayload"
     
    Invoke-WebRequest -Uri $apigeeDomain -Method 'POST' -ContentType 'application/json; charset=utf-8' -Body $reqPayload -Headers $headers
    
}
elseif ( $Action -eq "Create" -And $kvmJsonBodyValid -And $kvmNameValid) {
    
    $requestPayload = $KVMJsonBody | ConvertFrom-Json | ConvertFrom-Json
    Write-Host "Importing entry $($requestPayload.name) in KVM $KVMName"

    $reqPayload = $requestPayload | ConvertTo-Json

    $uri = "$apigeeDomain/$KVMName/entries"
     
    $response = Invoke-WebRequest -Uri $uri -Method 'POST' -ContentType 'application/json; charset=utf-8' -Body $reqPayload -Headers $headers
    
}
else {
    Write-Error "Invalid Action"
}
