Param (
  [Parameter(mandatory = $true)][string]$accessToken, # To receive GCP access token
  [Parameter(mandatory = $true)][string]$org, # To receive Apigee Organization where action will be performed      
  [Parameter(mandatory = $true)][string]$action, # To receive type of action script shall perform
  [Parameter(mandatory = $false)][string]$developerEmail, # To receive TargetServer name
  [Parameter(mandatory = $false)][string]$appName, # To receive JSON body for Create or Update Action
  [Parameter(mandatory = $false)][string]$adhocJsonBody # To receive JSON body for Create or Update Action
)

# Load utility functions
. "$PSScriptRoot\utilities.ps1"

# Set Global Variables  

$headers = @{Authorization = "Bearer $accessToken" }
$sourceOrgFolder = Get-SourceOrg -targetOrg $org  #call utility function from utilities script
$apigeeBaseUrl = "https://apigee.googleapis.com/v1/organizations/$org/developers"
Write-Output "SourceOrgFolder dir = $sourceOrgFolder"
$appsDirectory = "$sourceOrgFolder/apps"
Write-Output "Apps dir = $appsDirectory"
if ($action -ne "Delete") {
  $appsFiles = Get-ChildItem -Path $appsDirectory *.json
  $developersDirectory = "$sourceOrgFolder/developers/"
  Write-Output "Developer dir = $developersDirectory"
  $developersFiles = Get-ChildItem -Path $developersDirectory *.json
  $developeremailValid = ![string]::IsNullOrEmpty($developerEmail) -And ![string]::IsNullOrWhitespace($developerEmail) -And ($developerEmail) -ne "null"
  $adhocJsonDataValid = ![string]::IsNullOrEmpty($adhocJsonBody) -And ![string]::IsNullOrWhitespace($adhocJsonBody) -And $adhocJsonBody -ne "null"
  $appNameValid = ![string]::IsNullOrEmpty($appName) -And ![string]::IsNullOrWhitespace($appName) -And $appName -ne "null"
}
$successCount = 0
$failureCount = 0
$failedAppsName = @()


# Set global function

function perform-actions($appContent, $action, $email) {

  
  try {
    $appName = $appContent.name
    Write-Host "$action app $appName"
      
    # Get attributes array of apps object
    $attributesArray = @()
    $attributesArrayCount = 0
    $appContent.attributes | ForEach-Object { $attributesArrayCount++ ; $attributesArray += $_ }
    $attributesArrayJson = $attributesArray | ConvertTo-Json

    $jsonBody = @"
{

"appFamily" : "$($appContent.appFamily)",
"attributes" :$(If ($attributesArrayCount -gt 1 ) {"$attributesArrayJson"} Else {"[$attributesArrayJson]"}),
"callbackUrl" : "$($appContent.callbackUrl)",
"name" : "$($appContent.name)",
"status" : "$($appContent.status)"
}
"@ 
    
    Write-Host  "requestpayload  $jsonBody"
   
    if ($action -eq "Update") {
      $URI = "$apigeeBaseUrl/$email/apps/${appName}"
      $appCreateResponse = Invoke-WebRequest -Uri $URI -Method 'PUT' -ContentType 'application/json' -Body $jsonBody -Headers $headers
      Write-Output "App $appName updated successfully"
    } 
    else {
      $URI = "$apigeeBaseUrl/$email/apps"
      $appCreateResponse = Invoke-WebRequest -Uri $URI -Method 'POST' -ContentType 'application/json' -Body $jsonBody -Headers $headers
      Write-Output "App $appName imported successfully"
    }

    
    $content = ConvertFrom-Json $appCreateResponse.Content
    $credentials = $content.credentials
    $status = $content.status
    $appName = $appContent.name
    $consumerKey = $credentials[0].consumerKey  
        

    #Update app status to revoked, if given in file
    if ($appContent.status -eq "revoked" -And $status -eq "approved") {
      $revokeStatusURI = "$apigeeBaseUrl/$email/apps/${appName}?action=revoke"
      $appRevokedResponse = Invoke-WebRequest -Uri $revokeStatusURI -Method 'POST' -ContentType 'application/octet-stream' -Headers $headers
      Write-Output "Updated app status to revoked for app $appName"
    }elseif($appContent.status -eq "approved" -And $status -eq "revoked") {
            $revokeStatusURI = "$apigeeBaseUrl/$email/apps/${appName}?action=approve"
      	   $appRevokedResponse = Invoke-WebRequest -Uri $revokeStatusURI -Method 'POST' -ContentType 'application/octet-stream' -Headers $headers
            Write-Output "Updated app status to approved for app $appName"

}
              if ($action -eq "Create" -Or $action -eq "ImportAll"){ #Delete default key in case of Import and Create Action

		 if (![string]::IsNullOrEmpty($appContent.credentials[0].consumerKey))
		    { $deleteURI = "$URI/$appName/keys/$consumerKey"
                     $deleteResponse = Invoke-RestMethod -Uri $deleteURI -Method 'DELETE' -ContentType 'application/json'  -Headers $headers        
                     Write-Output "Default generated key and secret deleted for app $appName"
                    }
		    }

    # Get credentials array of apps object from request/file

    $appContent.credentials | ForEach-Object { 
      $attributesArray = @()
      $attributesArrayCount = 0
      $_.attributes | ForEach-Object { $attributesArrayCount++ ; $attributesArray += $_ }
      $attributesArrayJson = $attributesArray | ConvertTo-Json
      $scopesArray = @()
      $scopesArrayCount = 0
      $_.scopes | ForEach-Object { $scopesArrayCount++ ; $scopesArray += $_ } 
      $scopesArrayJson = $scopesArray | ConvertTo-Json
      $key = $env:AES_KEY
      $encryptedconsumerKey = $($_.consumerKey)
      $dcryptedconsumerKey = Decrypt-String -encryptedStringWithIV $encryptedconsumerKey -key $key
      $encryptedconsumerSecret = $($_.consumerSecret)
      $dcryptedconsumerSecret = Decrypt-String -encryptedStringWithIV $encryptedconsumerSecret -key $key

      $expiresInSeconds = $_.expiresAt	
      if($_.expiresAt -ne "-1" ){
	$now = [DateTimeOffset]::Now.ToUnixTimeSeconds()
	if($("$expiresInSeconds").Length -gt 10){
	   $expiresInSeconds = "$($expiresInSeconds)".Substring(0,10)
	   $expiresInSeconds = $($expiresInSeconds/1)
	   }
	$expiresInSeconds = $($expiresInSeconds-$now)
 	if($expiresInSeconds -lt 0){
  	    $expiresInSeconds = -1	
	}
      }
      
      $importCredential = @"
{
"consumerKey" : "$($dcryptedconsumerKey)",
"consumerSecret" : "$($dcryptedconsumerSecret)",
"expiresInSeconds" : $($expiresInSeconds),
"status" : "$($_.status)",
"scopes": $(If ($scopesArrayCount -gt 1 ) {"$scopesArrayJson"} Else {"[$scopesArrayJson]"}),
"attributes" : $(If ($attributesArrayCount -gt 1 ) {"$attributesArrayJson"} Else {"[$attributesArrayJson]"}) 
}
"@ 
      $validKeySecret = ![string]::IsNullOrEmpty($encryptedconsumerKey) -And ![string]::IsNullOrWhitespace($encryptedconsumerKey)
      if ($validKeySecret) { 
        # Delete newly created key and secret
           if ($action -eq "Update")
	     {
	      $updateKeyStatusURI = "$URI/keys/${dcryptedconsumerKey}?action=revoke"
             }else {
	             $importSecretURI = "$URI/$appName/keys/create"
	            $updateKeyStatusURI = "$URI/$appName/keys/${dcryptedconsumerKey}?action=revoke"
            }                     

	
         if ($action -eq "Create" -Or $action -eq "ImportAll"){
		# Import existing secret
		$importSecretResponse = Invoke-WebRequest -Uri $importSecretURI -Method 'POST' -ContentType 'application/json' -Body $importCredential -Headers $headers
       		 Write-Output "Existing key and secret imported for app $appName " 
             }
        # Update status to revoked if available in source file
        if ($_.status -eq "revoked") {
            $updateStatusRevokedResp = Invoke-WebRequest -Uri $updateKeyStatusURI -Method 'POST'  -ContentType 'application/octet-stream' -Headers $headers
            Write-Host "Updated key status to revoke"
	}
      }

      


      # Associating products
	
      $productsArray = @()
      $productsArrayCount = 0
      $revokedProductsArray = @()
      $revokedProductsArrayCount = 0
      $_.apiProducts | ForEach-Object {  
        $productsArrayCount++ ; $productsArray += $_.apiproduct 
        if ($_.status -eq "revoked")
        { $revokedProductsArrayCount++ ; $revokedProductsArray += $_.apiproduct } 
      }
      $productsArrayJson = $productsArray | ConvertTo-Json
      $revokedProductsArrayJson = $revokedProductsArray | ConvertTo-Json
    
      $addProducts = @"
{
"apiProducts" : $(If ($productsArrayCount -gt 1 ) {"$productsArrayJson"} Else {"[$productsArrayJson]"}),
"attributes" : [$attributesArrayJson]
}
"@ 

      Write-Output "Associate products to key for app $appName"
      if ($validKeySecret -And $action -ne "Update")
      { $addProductsURI = "$URI/$appName/keys/$dcryptedconsumerKey" }
      elseif ($action -eq "Update")
      { 
      if ($validKeySecret) 
      {
      $addProductsURI = "$URI/keys/$dcryptedconsumerKey"
      }else
      {$addProductsURI = "$URI/keys/$consumerKey"}
      }
      
       
       
      if ($productsArrayJson.Count -gt 0) {
        
        Write-Output "Add following products  $addProducts"
        $response = Invoke-WebRequest -Uri $addProductsURI -Method 'POST' -ContentType 'application/json' -Body $addProducts -Headers $headers
        Write-Output "Products added for app $appName"
      }

      if ($revokedProductsArrayJson.Count -gt 0) {
        $_.apiProducts | ForEach-Object {
          if ($_.status -eq "revoked") {
            $productName = $_.apiproduct
            $addProductsRevekeURI = "${addProductsURI}/apiproducts/${productName}?action=revoke"
            Write-Output "Update revoke status for ${productName}"
            $response = Invoke-WebRequest -Uri $addProductsRevekeURI -Method 'POST' -ContentType 'application/json' -Headers $headers
            Write-Output "Status updated to revoke for product $productName and app $appName" 
          } 
        }
      }
    }
    $global:successCount++
  }
  catch {
    $global:failureCount++
    $global:failedAppsName += $appName
    if ($action -eq "ImportAll") 
    { Write-Host "An error occurred while importing app $appName : $_" }
    else
    { Write-Error "An error occurred while importing app $appName : $_" }
      
      
  }
}

# Action choices

if ( $action -eq "ImportAll" ) {
  Write-Host "Start ImportAll of apps"
    
  foreach ($appFile in $appsFiles) {
  
    Set-Location $appsDirectory
    $appContent = Get-Content $appFile | ConvertFrom-Json
    cd .. 
    cd ..
    # Get developer details
    $developerId = $appContent.developerId
    Set-Location $developersDirectory
    $developerFile = Get-ChildItem -Recurse *.json | Select-String $developerId -List | Select Path | Get-Content | ConvertFrom-Json
    if ([string]::IsNullOrEmpty($developerFile.email)) { Write-Error "No matching developer email found for $developerId" }
    $email = $developerFile.email.ToLower()
    Write-Host "Found developer email $email for developer ID $developerId"     
    perform-actions $appContent	$action	$email
    cd ..
    cd ..
  }

  $summary = "Apps Import All:- Total $($global:successCount + $global:failureCount) : Succeeded $global:successCount Failed $global:failureCount. Failed Apps Names :$($global:failedAppsName -join ",")"
  if ( $global:failureCount -gt 0 ) {
    Write-Error $summary
  }
  else {
    Write-Host $summary
  }
}
elseif ($action -eq "Delete") {
  Write-Output "Start deletion of App $appName." 
  $URI = "$apigeeBaseUrl/$developerEmail/apps/$appName"
  Write-Output "Start deletion of App with URI $appName. $URI " 
  Invoke-WebRequest -Uri $URI -Method 'Delete' -Headers $headers
  Write-Output "End deletion of App $appName." 
}
elseif ($action -eq "Update" -Or $action -eq "Create") {
   
  if ($adhocJsonDataValid -And $developeremailValid) {
    $fileContent = $adhocJsonBody | ConvertFrom-Json | ConvertFrom-Json
    $appName = $fileContent.name
    Write-Output "Start adhoc $action of App $appName "
    perform-actions $fileContent $action $developerEmail
  }
  elseif ($developeremailValid -And $appNameValid) {
    Write-Output "Start $action of App $appName "
    Set-Location $appsDirectory
    $appFiles = (Get-ChildItem -Recurse *.json | Select-String $appName -List | Select Path).Path
    Write-Output "Following is appfiles $appFiles and appName is $appName"
    foreach($file in $appFiles){
    $fileContent = Get-Content -Path $file | ConvertFrom-Json
    $appNameFromFile = $fileContent.name.toLower()
    if($appNameFromFile -eq $appName.toLower())
    {perform-actions $fileContent $action $developerEmail}
    }
  }else {Write-Error "Not all required parameters provided...aborting job"}
  Write-Output "End $action of App $appName " 
}
else {
  Write-Error "Invalid option selected...aborting flow"
}
