
# Function for sending notifications
function Post-MessagesToTeams {
    param (
        $title, $summary, $workflowName, $runId, $runNumber, $orgName, $executionTimestamp, $triggeredByName, $eventType, $gitBranch, $jobStatus, $artifactLink, $teamsWebhookURL, $messageColor, $themeColor
    )
    
    # Determine the notification parameters based on the job status
    if ($jobStatus -eq "success") {
        $TITLE = "GitHub Notification - Job completed successfully"
        $SUMMARY = "GitHub Notification from Apigee Export Management completed successfully"
        $MESSAGE_COLOR = "green"
        $THEME_COLOR = "008000"
    } else {
        $TITLE = "GitHub Notification - Job failed to complete due to errors"
        $SUMMARY = "GitHub Notification from Apigee Export Management has failed due to some errors"
        $MESSAGE_COLOR = "red"
        $THEME_COLOR = "D60000"
    }
    Write-Host "EVENT_TYPE:$EVENT_TYPE"
    # Check the event type and set the eventType variable
    if ($EVENT_TYPE -eq "workflow_dispatch") {
        Write-Host "This workflow was triggered manually."
        $eventType = "Manual Run"
        # Add your manual run-specific logic here
    } elseif ($EVENT_TYPE -eq "schedule") {
        Write-Host "This workflow was triggered by a schedule."
        $eventType = "Scheduled Run"
        # Add your scheduled run-specific logic here
    } else {
        Write-Host "Unknown event: $EVENT_TYPE"
        $eventType = "Unknown"
        # Handle other event types as needed
    }
    
    # Create the JSON payload for the notification
    $JSON = @{
        title = $TITLE
        summary = $SUMMARY
        text = "Workflow Name: $workflowName<br>Run ID: $runId<br>Run Number: $runNumber<br>Org: $orgName<br>Timestamp: $executionTimestamp<br>Triggered by: <b> $triggeredByName </b><br>EventType: $eventType <br>Branch: $gitBranch<br> Status: <font color='$MESSAGE_COLOR'><b>$jobStatus</b></font><br>Artifact Link: $artifactLink"
        themeColor = $THEME_COLOR
    } | ConvertTo-Json

    try {
        # Send the notification to Teams
        $response = Invoke-RestMethod -Uri $env:TEAMS_WEBHOOK_URL -Method POST -Headers @{"Content-Type"="application/json"} -Body $JSON
        return $response

    } catch {
        Write-Output "Failed to send notification: $_"
        return $null  # Indicates failure
    }
    }

function Get-SourceOrg {
   param (
        $targetOrg
    )
       if ($targetOrg.ToUpper().Contains("APG-DEV") -or $targetOrg.ToUpper().Contains("CENTERING") ) {
    $sourceDirectory = "fg-iz-apg-dev-eu-apigee-a141"
} elseif ($targetOrg.ToUpper().Contains("APG-PROD")){
    $sourceDirectory = "fg-iz-apg-prod-eu-apigee-c557"
} else {
    Write-Error "Invalid Org"
}
         
     return   $sourceDirectory  
}

function Get-ProxyCodeQualityCheck {
   param (
        $homeDir,$proxyName,$proxyVersion,$targetOrg
    )
       Set-Location ../node_modules/apigeelint/
       $sourceOrgFolder =  Get-SourceOrg -targetOrg $targetOrg
       $proxyVersionFolder = "$homeDir/$sourceOrgFolder/proxies/$proxyName/$proxyVersion"
       $apiProxyFolder = Get-ChildItem -Path $proxyVersionFolder -Directory | %{$_.FullName}
       try {
         .\cli.js -s $apiProxyFolder/apiproxy/ -f html.js -e PO013,PO025 > $homeDir/apigeelint-out.html 
            } catch {
         Write-Host "An error occured during code quality check"
         Write-Host $_.Exception.Message
        }
         
         
}

function Get-ShareflowCodeQualityCheck {
   param (
        $homeDir,$sharedflowName,$sharedflowVersion,$targetOrg
    )
       Set-Location ../node_modules/apigeelint/
       $sourceOrgFolder =  Get-SourceOrg -targetOrg $targetOrg
       $sharedflowVersionFolder = "$homeDir/$sourceOrgFolder/shared-flows/$sharedflowName/$sharedflowVersion"
       $flowFolder = Get-ChildItem -Path $sharedflowVersionFolder -Directory | %{$_.FullName}
       try {
         .\cli.js -s $flowFolder/sharedflowbundle/ -f html.js -e PO013,PO025 > $homeDir/apigeelint-out.html 
            } catch {
         Write-Host "An error occured during code quality check"
         Write-Host $_.Exception.Message
        }
         
         
}


function Get-TargetOrgSecretKey {
   param (
        $targetOrg
    )
       if ($targetOrg.ToUpper().Contains("APG-DEV") -or $targetOrg.ToUpper().Contains("CENTERING") ) {
    $targetOrgSecretKey = "GCP_EU_NONPROD_SERVICE_ACCOUNT_KEY_JSON"
} elseif ($targetOrg.ToUpper().Contains("APG-PROD")){
    $targetOrgSecretKey = "GCP_EU_PROD_SERVICE_ACCOUNT_KEY_JSON"
} else {
    Write-Error "Invalid Org"
}
      
     return   $targetOrgSecretKey  
}

function Create-AesManagedObject($key,$IV) {
    $aesManaged = New-Object "System.Security.Cryptography.AesManaged"
    $aesManaged.Mode = [System.Security.Cryptography.CipherMode]::CBC 
    $aesManaged.BlockSize = 128
    $aesManaged.KeySize = 256
     if ($IV) {$aesManaged.IV = $IV}
     if ($key) {$aesManaged.Key = $key}
    
    return $aesManaged
}


function Encrypt-String {
    Param (
     $plaintext,
     $key
     )
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($plaintext)
    $key = [System.Text.Encoding]::UTF8.GetBytes($key.PadRight(32))
    $aesManaged = Create-AesManagedObject $key
    $encryptor = $aesManaged.CreateEncryptor()
    $encryptedData = $encryptor.TransformFinalBlock($bytes, 0, $bytes.Length);
    [byte[]] $fullData = $aesManaged.IV + $encryptedData
    $encryptedBase64 = [System.Convert]::ToBase64String($fullData)
     return $encryptedBase64 
                      
}

function Decrypt-String {
    Param (
  $encryptedStringWithIV,
  $key
)
    $bytes = [System.Convert]::FromBase64String($encryptedStringWithIV)
    $IV = $bytes[0..15]
    $key = [System.Text.Encoding]::UTF8.GetBytes($key.PadRight(32))
    $aesManaged = Create-AesManagedObject $key $IV
    $decryptor = $aesManaged.CreateDecryptor();
    $unencryptedData = $decryptor.TransformFinalBlock($bytes, 16, $bytes.Length-16);
    $unencryptedString = [System.Text.Encoding]::UTF8.GetString($unencryptedData).Trim([char]0);
    $aesManaged.Dispose();
    return $unencryptedString;
}

function Decrypt-KVM {
    param(
        [string]$keyHex,
        $json
    )
    
    $jsonContent = $json | ConvertFrom-Json

    # Specify the fields you want to decrypt
    $fieldsToDecrypt = "name", "value"

    # Define the path to the fields in your JSON data
    $fieldPath = "keyValueEntries"

    # Create an AES object for decryption
    $AES = New-Object System.Security.Cryptography.AesCryptoServiceProvider
    $AES.KeySize = 256
    $AES.Key = [System.Text.Encoding]::UTF8.GetBytes($keyHex.PadRight(32))
    $AES.Mode = [System.Security.Cryptography.CipherMode]::CBC

    # Loop through the JSON data and decrypt specified fields
    foreach ($entry in $jsonContent.$fieldPath) {
        foreach ($field in $fieldsToDecrypt) {
            Write-Host "Entered into FOR EACH..!"
            $encryptedField = $entry.$field
            # Write-Host "encryptedField: $encryptedField"

            if ($encryptedField) {
                $encryptedValueBase64 = $encryptedField.EncryptedValue
                $IVBase64 = $encryptedField.IV

                if (![string]::IsNullOrEmpty($IVBase64)) {
                    # Convert IV and encrypted value to bytes
                    $IV = [System.Convert]::FromBase64String($IVBase64)
                    $encryptedBytes = [System.Convert]::FromBase64String($encryptedValueBase64)

                    # Create a decryptor with the specified IV
                    $decryptor = $AES.CreateDecryptor($AES.Key, $IV)

                    # Decrypt the data
                    $decryptedBytes = $decryptor.TransformFinalBlock($encryptedBytes, 0, $encryptedBytes.Length)
                    $decryptedText = [System.Text.Encoding]::UTF8.GetString($decryptedBytes)

                    # Update the JSON object with the decrypted value
                    $entry.$field = $decryptedText
                } else {
                    Write-Host "IV is missing for $field. Skipping decryption."
                }
            }
        }
    }

    $decryptedJsonData = $jsonContent | ConvertTo-Json -Depth 10
    return $decryptedJsonData
}


# Define the Decrypt-APPS function
function Decrypt-APPS {
    param(
        [string]$keyHex,
        $json
    )

    try {
        # Parse and display the file content (assuming it's Base64 encoded JSON)
         #$jsonContent = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($json))

        # Convert the modified JSON data back to a PowerShell object
        $encryptedJsonData = $json | ConvertFrom-Json

        # Specify the fields you want to decrypt
        $fieldsToDecrypt = "consumerKey", "consumerSecret"

        # Create a new AES object with the specified key and AES mode
        $AES = New-Object System.Security.Cryptography.AesCryptoServiceProvider
        $AES.KeySize = 256  # Set the key size to 256 bits for AES-256
        $AES.Key = [System.Text.Encoding]::UTF8.GetBytes($keyHex.PadRight(32))
        $AES.Mode = [System.Security.Cryptography.CipherMode]::CBC

        # Loop through the specified fields and decrypt their values
        foreach ($field in $fieldsToDecrypt) {
            # Check if the field contains a valid Base64 string
               if ($encryptedJsonData.credentials[0].$field -ne "System.Collections.Hashtable") {
            $encryptedValueBase64 = $encryptedJsonData.credentials[0].$field.EncryptedValue
            $IVBase64 = $encryptedJsonData.credentials[0].$field.IV

                # Convert IV and encrypted value to bytes
                $IV = [System.Convert]::FromBase64String($IVBase64)
                $encryptedBytes = [System.Convert]::FromBase64String($encryptedValueBase64)

                # Create a decryptor
                $decryptor = $AES.CreateDecryptor($AES.Key, $IV)

                # Decrypt the data
                $decryptedBytes = $decryptor.TransformFinalBlock($encryptedBytes, 0, $encryptedBytes.Length)
                $decryptedText = [System.Text.Encoding]::UTF8.GetString($decryptedBytes)

                # Update the JSON object with the decrypted value
                $encryptedJsonData.credentials[0].$field = $decryptedText
            }
        }

        # Display the JSON object with decrypted values
        $decrypteddata =  $encryptedJsonData | ConvertTo-Json -Depth 10
        Write-Host "Decrypted Data:"
        Write-Host $decrypteddata
        return $decrypteddata
    } catch {
        Write-Host "An error occurred during decryption: $_"
        return $null  # or handle the error as needed
    }
}
