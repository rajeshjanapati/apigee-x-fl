Param (
    [Parameter(mandatory = $true)][string]$AccessToken, # To receive GCP access token
    [Parameter(mandatory = $true)][string]$Org, # To receive Apigee Organization where action will be performed  
    [Parameter(mandatory = $true)][string]$ApiKey # To recieve New Relic Api Key
)

$headers = @{Authorization = "Bearer $AccessToken" }

$dtformat = "MM/dd/yyyy+HH:mm"
$schedulerDelay = 10
$endTime = Get-Date -f $dtformat
$startTime = [datetime]::ParseExact($endTime, $dtformat, $Null).AddMinutes(-$schedulerDelay).ToString($dtformat)
$timeRange = "timeRange=$startTime~$endTime"
#$timeRange = "timeRange=10/16/2023+00:00~10/19/2023+23:59"
Write-Host "Time Range for scheduler $startTime to $endTime"

$instanceUri = "https://apigee.googleapis.com/v1/organizations/$Org/instances"
$apigeeDomain = "https://apigee.googleapis.com/v1/organizations/$Org/environments"
$newRelicUri = "https://log-api.eu.newrelic.com/log/v1?Api-Key=$ApiKey"

$instances = Invoke-WebRequest -Uri $instanceUri -Method 'GET' -ContentType 'application/json; charset=utf-8' -Headers $headers | ConvertFrom-Json
$instancesArray = [System.Collections.ArrayList]@()
$instancesArray = $instances.instances

$environments = Invoke-WebRequest -Uri $apigeeDomain -Method 'GET' -ContentType 'application/json; charset=utf-8' -Headers $headers | ConvertFrom-Json
Write-Host "Env $environments"

$metricNames = @("tps", "sum(cache_hit)", "sum(is_error)", "max(request_processing_latency)", "max(target_response_time)", "max(total_response_time)", "sum(target_error)", "sum(ax_cache_executed)", "sum(policy_error)", "sum(message_count)" )
Write-Host "Dimension Metrics to extract $metricNames"

function Get-Metrics {
    Param(
        $dimension,
        $metricName
    )
    if ( $dimension.environments.Count -ne 0 -And $dimension.environments[0].metrics.Count -ne 0 ) {
        $value = $dimension.environments[0].metrics[0].values[0]
    }
    else {
        $value = -1
    }
    $dimensionMetrics = @{
        name  = $metricName
        value = $value
    }

    return $dimensionMetrics
}

foreach ($inst in $instancesArray) {
	Write-Host "Instance location: $($inst.location)"
	$hostRegion = "filter=(ax_dn_region eq '$($inst.location)')"
 	Write-Host "Instance filter: $hostRegion"
	foreach ( $environment in $environments ) {
	    
	    $envUri = "$apigeeDomain/$environment/stats/?select"
	    $metrics = New-Object PsObject
	
	    foreach ( $metricName in $metricNames ) {
	        $metricUri = "$envUri=$metricName&$timeRange&$hostRegion"
	        $metricResponse = Invoke-WebRequest -Uri $metricUri -Method 'GET' -ContentType 'application/json; charset=utf-8' -Headers $headers | ConvertFrom-Json
	        Write-Host "$metricName $($metricResponse | ConvertTo-Json -Depth 10)"
		
		$thisMetric = Get-Metrics -dimension $metricResponse -metricName $metricName
		$metrics | Add-Member –membertype NoteProperty -name $thisMetric.name -value $thisMetric.value
	    }
		
	    $metrics = $metrics | ConvertTo-Json
	    Write-Host "Metrics body $metrics"
	    $indexEnv = $environment -replace "-","_"
	    $index = "apigee_x_runtime_nonprod_eu_$indexEnv"
	    $requestPayload = @{
	        sourcetype = "github_apigee_x_actions"
	        logtype    = "apigee_x_environment"
		instance = $($inst.location)
	        indexname  = $index
	       	message    = $metrics
	    }
	
	    $reqPayload = $requestPayload | ConvertTo-Json -Depth 10
	    Write-Host "New Relic Request Payload for $environment :- $reqPayload"
	
	    Invoke-WebRequest -Uri $newRelicUri -Method 'POST' -ContentType 'application/json; charset=utf-8' -Body $reqPayload
		
	}
}
