# Input parameters

Param (
    [Parameter(mandatory = $true)][string]$accessToken, # To receive GCP access token
    [Parameter(mandatory = $true)][string]$org, # To receive Apigee Organization where action will be performed      
    [Parameter(mandatory = $true)][string]$action, # To receive type of action script shall perform
    [Parameter(mandatory = $false)][string]$env, # To receive environment where proxy will be deployed
    [Parameter(mandatory = $false)][string]$sharedflowName, # To receive Shared flow name  
    [Parameter(mandatory = $false)][string]$edgeSharedflowVersion, # To receive Shared flow edge version which will be deployed
    [Parameter(mandatory = $false)][string]$XSharedflowVersion # To receive Shared flow edge version which will be deployed
    
)

# Load utility functions
. "$PSScriptRoot\utilities.ps1"

# Set Variables 

$headers = @{Authorization = "Bearer $accessToken " }
$sourceOrgFolder = Get-SourceOrg -targetOrg $org  #call utility function from utilities script
$sharedflowDirectory = "$sourceOrgFolder/shared-flows"
$currentDir = Get-Location
$sharedFlowEnvDirectory = "$currentDir/$sourceOrgFolder/environments/$env/shared-flows"
$apigeeDomain = "https://apigee.googleapis.com/v1/organizations/$org"

$sharedFlowDeployedList = @()

function Deploy-SharedFlow {
    Param(
        $sharedFlowName
    )
    
    if ( $sharedFlowDeployedList -notcontains $sharedFlowName ) {
       
        $sharedFlowPath = "$sharedFlowEnvDirectory/$sharedFlowName"
        $sharedFlowDeployVersion = Split-Path -Path (Get-ChildItem $sharedFlowPath -Directory ).FullName -Leaf        
        Write-Host "Deploying Shared Flow $sharedFlowName and Revision $sharedFlowDeployVersion to $env"            
                    
        $sharedFlowPoliciesPath = "$sharedflowDirectory/$sharedFlowName/$sharedFlowDeployVersion/$org-sharedflows-$sharedFlowName-rev$sharedFlowDeployVersion/sharedflowbundle/policies" 
        $dependentSharedFlowList = @()
        Get-ChildItem $sharedFlowPoliciesPath *.xml | ForEach-Object {
            
            $sharedFlowPolicyName = Split-Path -Path $_.FullName -Leaf
            $sharedFlowPolicyPath = "$sharedFlowPoliciesPath/$sharedFlowPolicyName"
            [xml]$sharedFlowPolicyContent = Get-Content $sharedFlowPolicyPath
            if ( $sharedFlowPolicyContent.FlowCallout -ne $null -And $sharedFlowPolicyContent.FlowCallout.SharedFlowBundle -ne $null ) {
                
                
                $dependentSharedFlowName = $sharedFlowPolicyContent.FlowCallout.SharedFlowBundle
                if ( $sharedFlowDeployedList -notcontains $dependentSharedFlowName ) {
                    
                    Write-Host "Undeployed Dependent Shared Flow Name $dependentSharedFlowName"
                    $dependentSharedFlowList += Deploy-SharedFlow -sharedFlowName $dependentSharedFlowName
                    
                }
            }
        }

        $uri = "$apigeeDomain/environments/$env/sharedflows/$sharedFlowName/revisions/$sharedFlowDeployVersion/deployments?override=true"
        try {
            Invoke-WebRequest  -Uri $uri -Method Post -ContentType 'application/json; charset=utf-8' -Headers $headers
        }
        catch {
            Write-Host "An error occurred while deploying $sharedFlowName : $_"
        }
        
    }

    $return = @()
    $dependentSharedFlowList | ForEach-Object { $return += $_ }
    $return += $sharedFlowName
    return $return           
}

# Different actions

if ($action -eq "ImportSharedflowVersion") {
    
    Write-Host "Start ImportSharedflowVersion for sharedflow $sharedflowName & version $edgeSharedflowVersion"
    Set-Location $sharedflowDirectory
    $currentdir = Get-Location
    $sharedflowVersionFolder = "$currentdir/$sharedflowName/$edgeSharedflowVersion"

    if ($sharedflowName -ne 'null' -AND $edgeSharedflowVersion -ne 'null' -AND (Test-Path $sharedflowVersionFolder )) {
        
        Set-Location $sharedflowVersionFolder
        $zipFile = Get-ChildItem *.zip
        $requestFile = @{file = Get-Item -Path $zipFile }
        $uri = "$apigeeDomain/sharedflows?action=import&name=$sharedflowName&validate=true"
        Invoke-WebRequest  -Uri $uri -Method Post -Form $requestFile -Headers $headers
        Write-Host "End ImportSharedFlowVersion for SharedFlow $sharedflowName & version $edgeSharedflowVersion"
    }
    else {
        Write-Error "Error ImportSharedFlowVersion for SharedFlow $sharedflowName & version $edgeSharedflowVersion : Invalid Shared flow or version"
    }
}
elseif ($action -eq "ImportTop5SharedflowVersion") {
    
    Write-Host "Start ImportTop5SharedFlowVersion for SharedFlow $sharedflowName"
    Set-Location $sharedflowDirectory
    $currentdir = Get-Location
    $shareflowFolder = "$currentdir\$sharedflowName"
    if ($sharedflowName -ne 'null' -AND (Test-Path $shareflowFolder )) {   
        $currentdir = Get-Location
        Set-Location $shareflowFolder
        $versionList = Get-ChildItem -Directory | Sort-Object -Property { $_.Name -as [int] } -Descending
        $versionCount = (Get-ChildItem | Measure-Object).count
        Write-Host "Total $versionCount in folder  $shareflowFolder" 
        
        if ($versionCount -ge 5) {
            $loopCount = 5 
        }
        else { $loopCount = $versionCount }

        for ($i = $loopCount - 1 ; $i -ge 0 ; $i--) {
            
            $versionFolder = $versionList[$i]
            Set-Location $versionFolder
            $zipFile = ls *.zip
            Write-Host "Zip file name $zipFile"
            $requestFile = @{file = Get-Item -Path $zipFile }
            $Uri = "$apigeeDomain/sharedflows?action=import&name=$sharedflowName&validate=true"
            Invoke-WebRequest  -Uri $uri -Method Post -Form $requestFile -Headers $headers
            Write-Host "Imported Zip file  $zipFile"
            Set-Location ..
             
        } 
        
    }
    else {
        Write-Error "Error ImportTop5SharedFlowVersion for SharedFlow $sharedflowName : Invalid shared flow"
    }

    Write-Host "End ImportTop5SharedFlowVersion for SharedFlow $sharedflowName"
}
elseif ($action -eq "DeleteSharedflowVersion") {
        Write-Host "Start DeleteSharedFlowVersion for SharedFlow $sharedflowName & version $XSharedflowVersion"
   if ($sharedflowName -ne 'null' -AND $XSharedflowVersion -ne 'null') {
        $uri = "$apigeeDomain/sharedflows/$sharedflowName/revisions/$XSharedflowVersion"
        Invoke-WebRequest  -Uri $uri -Method Delete -Headers $headers
      }
   else
       {
        Write-Error "Error DeleteSharedFlowVersion for SharedFlow $sharedflowName & version $XSharedflowVersion : Invalid sharedflow or version"
       }
        Write-Host "End DeleteSharedFlowVersion for SharedFlow $sharedflowName & version $XSharedflowVersion"
}
elseif ($action -eq "DeleteSharedflow") {
    Write-Host "Start DeleteSharedflow for sharedflow $sharedflowName"
   if ($sharedflowName -ne '') {
        $uri = "$apigeeDomain/sharedflows/$sharedflowName"
        Invoke-WebRequest  -Uri $uri -Method Delete -Headers $headers
      }
   else
       {
        Write-Error "Error DeleteSharedflow for sharedflow $sharedflowName  : Invalid sharedflow name"
       }
        Write-Host "End DeleteSharedflow for sharedflow $sharedflowName"
}
elseif ($action -eq "Deploy") {
   
    Write-Host "Start Deploy for sharedflow $sharedflowName & version $XSharedflowVersion"
    Set-Location $sharedflowDirectory
    $currentdir = Get-Location
    $sharedflowVersionFolder = "$currentdir\$sharedflowName\$XSharedflowVersion"
    if ($sharedflowName -ne 'null' -AND $XSharedflowVersion -ne 'null' -AND (Test-Path $sharedflowVersionFolder )) {

        Set-Location $sharedflowVersionFolder
        $uri = "$apigeeDomain/environments/$env/sharedflows/$sharedflowName/revisions/$XSharedflowVersion/deployments?override=true"
        Invoke-WebRequest  -Uri $uri -Method Post -ContentType 'application/json; charset=utf-8' -Headers $headers
    }
    else {
        Write-Error "End Deploy for sharedflow $sharedflowName & version $XSharedflowVersion : Invalid sharedflow name or version"
    }
    Write-Host "End Deploy for sharedflow $sharedflowName & version $XSharedflowVersion"
}
elseif ($action -eq "Undeploy") {
       
     Write-Host "Start Undeploy for sharedflow $sharedflowName & version $XSharedflowVersion"
    if ($sharedflowName -ne 'null' -AND $XSharedflowVersion -ne 'null') {
    $uri = "$apigeeDomain/environments/$env/sharedflows/$sharedflowName/revisions/$XSharedflowVersion/deployments"
    Invoke-WebRequest  -Uri $uri -Method Delete -ContentType 'application/json; charset=utf-8' -Headers $headers
     } else {
        Write-Error "Error Undeploy for sharedflow $sharedflowName & version $XSharedflowVersion : Invalid sharedflow name or version"
     }
     Write-Host "End  Undeploy for sharedflow $sharedflowName & version $XSharedflowVersion"
}
elseif ($action -eq "ImportAndDeploySharedflow") {
       
    Write-Host "Start ImportAndDeploySharedflow for sharedflow $sharedflowName & version $edgeSharedflowVersion"
    Set-Location $sharedflowDirectory
    $currentdir = Get-Location
    $sharedflowVersionFolder = "$currentdir/$sharedflowName/$edgeSharedflowVersion"

    if ($sharedflowName -ne 'null' -AND $edgeSharedflowVersion -ne 'null' -AND $env -ne 'null' -AND (Test-Path $sharedflowVersionFolder )) {
        
        Set-Location $sharedflowVersionFolder
        $zipFile = Get-ChildItem *.zip
        $requestFile = @{file = Get-Item -Path $zipFile }
        $uri = "$apigeeDomain/sharedflows?action=import&name=$sharedflowName&validate=true"
        $importResponse = Invoke-WebRequest  -Uri $uri -Method Post -Form $requestFile -Headers $headers
        if ($importResponse.statuscode -eq '200') {
             $revision = ConvertFrom-Json $importResponse.Content | Select-Object -expand "revision"
             Write-Host = "Sharedflow $sharedflowName imported with version $edgeSharedflowVersion,deploying to $env " 
            $uri = "$apigeeDomain/environments/$env/sharedflows/$sharedflowName/revisions/$revision/deployments?override=true"
             try {
               Invoke-WebRequest  -Uri $uri -Method Post -ContentType 'application/json; charset=utf-8' -Headers $headers
              } catch {
              
               Write-Host  "Got following exception while deploying sharedflow, deleting it."
               Write-Host  $_.Exception
               $uri = "$apigeeDomain/sharedflows/$sharedflowName/revisions/$revision"
               Invoke-WebRequest  -Uri $uri -Method Delete -Headers $headers
               Exit 1
              }
        Write-Host "End ImportAndDeploySharedflow for sharedflow $sharedflowName , version $edgeSharedflowVersion"
    }else{
        Write-Error "Error ImportAndDeploySharedflow for sharedflow $sharedflowName , version $edgeSharedflowVersion : Import failed"
        Write-Error $_.Exception.Message}
        }
    else {
        Write-Error "Error ImportAndDeploySharedflow for sharedflow $sharedflowName , version $edgeSharedflowVersion : Invalid sharedflow name or version or env"
    }
}
elseif ($action -eq "ImportAllSharedFlowVersions") {

    Write-Host "Start ImportAllSharedFlowVersions for SharedFlow $sharedflowName"
    Set-Location $sharedflowDirectory
    $currentdir = Get-Location
    $shareflowFolder = "$currentdir\$sharedflowName"
    if ($sharedflowName -ne 'null' -AND (Test-Path $shareflowFolder )) {   
        $currentdir = Get-Location
        Set-Location $shareflowFolder
        $versionList = Get-ChildItem -Directory | Sort-Object -Property { $_.Name -as [int] } -Descending
        [Array]::Reverse($versionList)
        Write-Host "Total $($versionList.Count) in folder  $shareflowFolder" 
        
        $versionList | ForEach-Object {
            
            $versionFolder = $_
            Set-Location $versionFolder
            $zipFile = ls *.zip
            Write-Host "Zip file name $zipFile"
            $requestFile = @{file = Get-Item -Path $zipFile }
            $Uri = "$apigeeDomain/sharedflows?action=import&name=$sharedflowName&validate=true"
            Invoke-WebRequest  -Uri $uri -Method Post -Form $requestFile -Headers $headers
            Write-Host "Imported Zip file  $zipFile"
            Set-Location ..
             
        } 
        
    }
    else {
        Write-Error "Error ImportAllSharedFlowVersions for SharedFlow $sharedflowName : Invalid shared flow"
    }

    Write-Host "End ImportAllSharedFlowVersions for SharedFlow $sharedflowName"
}
elseif ($action -eq "DeployAllSharedFlows") {
    
    if( $env -ne "null" ){
        Get-ChildItem $sharedFlowEnvDirectory -Directory | ForEach-Object {
            $sharedFlowName = Split-Path -Path $_.FullName -Leaf
            $sharedFlowDeployedList += Deploy-SharedFlow -sharedFlowName $sharedFlowName
        }
    }
    else {
        Write-Error "Error DeployAllSharedFlows : Invalid env"
    }
}
else {
    Write-Error "No valid input...skipping script."
}
