# Input parameters

Param (
  [Parameter(mandatory = $true)][string]$accessToken, # To receive GCP access token
  [Parameter(mandatory = $true)][string]$org, # To receive Apigee Organization where action will be performed     
  [Parameter(mandatory = $true)][string]$action, # To receive type of action script shall perform
  [Parameter(mandatory = $false)][string]$targetEnv, # To receive environment where keystores will be imported
  [Parameter(mandatory = $false)][string]$sourceEnv, # To receive environment from where keystores will be exported
  [Parameter(mandatory = $false)][string]$keystoreName,# To receive name of Keystore
  [Parameter(mandatory = $false)][string]$adhocJsonBody # To receive JSON body for Create or Update Action
)

# Load utility functions
. "$PSScriptRoot\utilities.ps1"

# Set Variables 

$headers = @{Authorization = "Bearer $accessToken " }
$sourceOrgFolder = Get-SourceOrg -targetOrg $org  #call utility function from utilities script
$environmentDirectory = "$sourceOrgFolder/environments"
$headers = @{Authorization = "Bearer $accessToken " }
$apigeeDomain = "https://apigee.googleapis.com/v1/organizations/$org"
$keystoreNameValid = ![string]::IsNullOrEmpty($keystoreName) -And ![string]::IsNullOrWhitespace($keystoreName) -And $keystoreName -ne "null"
$adhocJsonDataValid = ![string]::IsNullOrEmpty($adhocJsonBody) -And ![string]::IsNullOrWhitespace($adhocJsonBody) -And $adhocJsonBody -ne "null"


if ($action -eq "ImportAll") {

  Write-Host "Start ImportAll keystores into target $targetEnv from source env $sourceEnv"
  $successCount = 0
  $failureCount = 0
  $failedKeyStoreName = @()
  Set-Location $environmentDirectory/$sourceEnv/keystores
  $keystoreFiles = Get-ChildItem -Path .\*.json
  foreach ($file in $keystoreFiles ) {
    try {	 
      $fileContent = Get-Content $file | ConvertFrom-Json
      $keyStoreName = $fileContent.name
      $jsonbody = @"
{
  "name": "$($keyStoreName)",
}
"@ 
      Write-Host "Following is keystore request object $jsonbody"
      $Uri = "$apigeeDomain/environments/$targetEnv/keystores"
      Invoke-WebRequest  -Uri $Uri -Method Post -ContentType 'application/json' -Headers $headers -Body $jsonbody
      $successCount++
    }
    catch {
      # Handle any other exceptions that may occur
      Write-Host "An error occurred while importing keystore $keyStoreName"
      Write-Host  $_.Exception.Message
      $failureCount++
      $failedKeyStoreName += $keyStoreName
    }
  }
  $summary = "KeyStore Import All:- Total $($successCount + $failureCount) : Succeeded $successCount Failed $failureCount. Failed Key Stores Names $($failedKeyStoreName -join ",")"
  if ( $failureCount -gt 0 ) {
    Write-Error $summary
  }
  else {
    Write-Host $summary
  }
     
}
elseif ($action -eq "Create") {

  Write-Host "Create keystore $keystoreName into target environment $targetEnv "
    
  if ($adhocJsonDataValid) {
    $adhocJsonBodyContent = $adhocJsonBody|ConvertFrom-Json|ConvertFrom-Json
    $keyStoreName = $adhocJsonBodyContent.name
    $jsonbody = @"
{
  "name": "$($keyStoreName)",
}
"@ 
  }elseif($keystoreNameValid -And !$adhocJsonDataValid) {
  Set-Location $environmentDirectory/$sourceEnv/keystores
  $keyStoreFileContent = Get-ChildItem -Recurse *.json | Select-String $keystoreName -List | Select Path | Get-Content | ConvertFrom-Json
  $keyStoreName = $keyStoreFileContent.name
   
  $jsonbody = @"
{
  "name": "$($keyStoreName)",
}
"@ 
}else
{
Write-Error "Both keystore-name & Adhoc JSON body are invalid." 
}
$Uri = "$apigeeDomain/environments/$targetEnv/keystores"
Write-Host $fileContent
Invoke-WebRequest  -Uri $Uri -Method Post -ContentType 'application/json' -Headers $headers -Body $jsonbody
Write-Host "End Create keystores $keystoreName into target environment $targetEnv"
} elseif ($action -eq "Delete") {

  Write-Host "Start Delete keystores for keystore $keystoreName"
  $Uri = "$apigeeDomain/environments/$targetEnv/keystores/$keystoreName"
  Invoke-WebRequest  -Uri $Uri -Method Delete -Headers $headers
  Write-Host "End Delete keystores for keystore $keystoreName"
}
else {
  Write-Error "No valid input...skipping script."
}
