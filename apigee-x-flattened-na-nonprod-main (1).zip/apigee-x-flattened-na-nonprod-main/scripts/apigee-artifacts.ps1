# Define Input required parameters
Param (
        [Parameter(mandatory = $true)][string]$AccessToken, # To receive GCP access token
        [Parameter(mandatory = $true)][string]$summary_file_name # To receive Apigee Organization where action will be performed
    )

    $org = $env:APIGEE_ORG

    # write-output Apigee Artifacts
    $baseURL = "https://apigee.googleapis.com/v1/organizations/"
    $headers = @{Authorization = "Bearer $AccessToken"}
    $keyAES = $env:AES_KEY

	# Load utility functions
	. "$PSScriptRoot\utilities.ps1"


 # ----------------------create apigee organisation level folder-------------------------------------------------

    # Specify the directory name = organization name
    $directoryName = $org

    # Initialize an empty string to store all environment summaries
    $allSummaries_Log = ""

    $org_Log = "Orgnaization Name - $org`r`n"

    $allSummaries_Log += $org_Log

    # Check if the directory exists
    if (!(Test-Path -PathType Container $directoryName)) {
        # If it doesn't exist, create it
        mkdir $directoryName
        cd $directoryName
    } 
    else {    
        # Remove the directory and its contents if it exists
        Remove-Item -Path $directoryName -Recurse
        
        # Introduce a 2-second delay
        Start-Sleep -Seconds 2
        
        # Recreate the directory
        mkdir $directoryName
        cd $directoryName
    }

    # -------------------------------- Organization - Proxies - All Revisions -------------------------------------------
        if(!(test-path -PathType container proxies)){
            mkdir "proxies"
            cd proxies
        }
        else {
            cd proxies
        }

        $path = $baseURL+$org+"/apis"
        $proxies = Invoke-RestMethod -Uri "https://apigee.googleapis.com/v1/organizations/$org/apis" -Method 'GET' -Headers $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60

        $path = $baseURL+$org+"/apis"
        $proxies = Invoke-RestMethod -Uri "https://apigee.googleapis.com/v1/organizations/$org/apis" -Method 'GET' -Headers $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60

        # Initialize an array to store proxy names
        $proxyNames_Success = @()
        $proxyNames_Failure = @()
        $proxyCountIn_Success = 0
        $proxyCountIn_Failed = 0

        foreach ($proxy in $($proxies.proxies)) {

            try {
                $proxyNames_Success += $proxy.name

                $path1 = $baseURL+$org+"/apis/"+$($proxy.name)+"/revisions"
                $proxyRevs = Invoke-RestMethod -Uri $path1 -Method:Get -Headers $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60

                foreach ($proxyRevs in $($proxyRevs)) {
                if(!(test-path -PathType container $($proxy.name))){
                    mkdir -p "$($proxy.name)"
                    cd $($proxy.name)
                    }
                    else {
                        cd $($proxy.name)
                    }
                
                    if(!(test-path -PathType container $($proxyRevs))){
                    mkdir -p "$($proxyRevs)"
                    cd $($proxyRevs)
                    }
                    else {
                        cd $($proxyRevs)
                    }
                
                    $path2 = $baseURL+$org+"/apis/"+$($proxy.name)+"/revisions/"+$($proxyRevs)+"?format=bundle"
                    $zipFile = $org+"-proxy-"+$($proxy.name)+"-rev"+$($proxyRevs)+".zip"
                    
                    $response = Invoke-RestMethod -Uri $path2 -Method:Get -Headers $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60 -OutFile $zipFile

                    Expand-Archive -Path $zipFile -Force
                    # Remove-Item -Path $zipFile -Force
                    cd ..
                    cd ..
                }
            }
            catch{
                $proxyNames_Failure += $proxy.name
            }  
        }
        cd..

        $proxyNamesList_Success =  $($proxyNames_Success -join ', ')
        $proxyNamesList_Failed =  $($proxyNames_Failure -join ', ')

        $proxyCountIn_Success = $proxyNames_Success.Count
        $proxyCountIn_Failed = $proxyNames_Failure.Count

        $org_Proxy_Log_Success = ("Org Proxies Exported Successfully to GitHub: Count - $proxyCountIn_Success, Proxy Names - $proxyNamesList_Success`r`n")# : "org Proxies API Executed Successfully but no Data found in the Response.`r`n"
        $org_Proxy_Log_Failed = ("Org Proxies Export Failed: Count - $proxyCountIn_Failed, Proxy Names - $proxyNamesList_Failed`r`n") #: ""

        $allSummaries_Log += $org_Proxy_Log_Success + $org_Proxy_Log_Failed

        $path = $baseURL+$org+"/apis"
        Invoke-RestMethod -Uri "https://apigee.googleapis.com/v1/organizations/$org/apis" -Method 'GET' -Headers $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60 -OutFile "$org-proxies.json"

    # -------------------------------- Organization - SharedFlows - All Revs --------------------------------------------
        if(!(test-path -PathType container shared-flows)){
            mkdir "shared-flows"
            cd shared-flows
        }
        else {
            cd shared-flows
        }

        $sharedflowpath = $baseURL+$org+"/sharedflows"
        $sharedflows = Invoke-RestMethod -Uri $sharedflowpath -Method:Get -Headers $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60

        # Initialize an array to store sharedflow names
        $sharedflowNames_Success = @()
        $sharedflowNames_Failure = @()
        $sharedflowCountIn_Success = 0
        $sharedflowCountIn_Failed = 0

        try {
            foreach ($sharedflow in $($sharedflows.sharedflows)) {

                # Store the shared flow name in the array
                $sharedflowNames_Success += $sharedflow.name

                $flowDetailRev = $baseURL+$org+"/sharedflows/"+$($sharedflow.name)+"/revisions"
                $FlowRevs = Invoke-RestMethod -Uri $flowDetailRev -Method:Get -Headers $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60

                foreach ($FlowRevs in $($FlowRevs)) {
                if(!(test-path -PathType container $($sharedflow.name))){
                    mkdir -p "$($sharedflow.name)"
                    cd $($sharedflow.name)
                    }
                    else {
                        cd $($sharedflow.name)
                    }
                
                    if(!(test-path -PathType container $($FlowRevs))){
                    mkdir -p "$($FlowRevs)"
                    cd $($FlowRevs)
                    }
                    else {
                        cd $($FlowRevs)
                    }
                
                    $flowDetailRev2 = $baseURL+$org+"/sharedflows/"+$($sharedflow.name)+"/revisions/"+$($FlowRevs)+"?format=bundle"
                    $sharedflowzipFile = $org+"-sharedflows-"+$($sharedflow.name)+"-rev"+$($FlowRevs)+".zip"

                    $response = Invoke-RestMethod -Uri $flowDetailRev2 -Method:Get -Headers $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60 -OutFile $sharedflowzipFile

                    Expand-Archive -Path $sharedflowzipFile -Force
                    # Remove-Item -Path $sharedflowzipFile -Force
                    cd ..
                    cd ..
                }
                
            }
        }
        catch{
            $sharedflowNames_Failure += $proxy.name
        }
        # Count the total number of shared flows
        $sharedflowNamesList_Success =  $($sharedflowNames_Success -join ', ')
        $sharedflowNamesList_Failed =  $($sharedflowNames_Failure -join ', ')

        $sharedflowCountIn_Success = $sharedflowNames_Success.Count
        $sharedflowCountIn_Failed = $sharedflowNames_Failure.Count

        $org_SharedFlow_Log_Success = ("Org SharedFlows Exported Successfully to GitHub: Count - $sharedflowCountIn_Success, SharedFlows Names - $sharedflowNamesList_Success`r`n") #: "org SharedFlows API Executed Successfully but no Data found in the Response.`r`n"
        $org_SharedFlow_Log_Failed = ("Org SharedFlows Export Failed: Count - $sharedflowCountIn_Failed, SharedFlows Names - $sharedflowNamesList_Failed`r`n") #: ""

        $allSummaries_Log += $org_SharedFlow_Log_Success + $org_SharedFlow_Log_Failed

        cd ..

        $sharedflowpath = $baseURL+$org+"/sharedflows"
        Invoke-RestMethod -Uri $sharedflowpath -Method:Get -Headers $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60 -OutFile "$org-sharedflows.json"
        
    # ---------------------------------- Organization -  KVMs - Entries -------------------------------------------------
        if(!(test-path -PathType container org-kvms)){
            mkdir "org-kvms"
            cd org-kvms
        }
        else {
            cd org-kvms
        }

        $org_KVM_Summaries = ""
        $KVMSummary = ""

        # Arrays to store org KVM names with and without entries
        $org_KVMsWithEntries_Success = @()
        $org_KVMsWithEntries_Failure = @()

        $org_KVMsWithoutEntries_Success = @()
        $org_KVMsWithoutEntries_Failure = @()

        $KVMsWithEntriesCount = 0
        $KVMsWithoutEntriesCount = 0

        $kvmpath = $baseURL+$org+"/keyvaluemaps"
        $orgkvms = Invoke-RestMethod -Uri $kvmpath -Method:Get -Headers $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60
        try {
            foreach ($orgkvm in $($orgkvms)) {
                # Define a function to encrypt org KVM Entries
                
                try {
                
                    $kvmpthtestpath = "https://apigee.googleapis.com/v1/organizations/$org/keyvaluemaps/$($orgkvm)/entries"
                
                    $response = Invoke-RestMethod -Uri $kvmpthtestpath -Method 'GET' -Headers $headers -ContentType "application/json" -ErrorAction Stop -TimeoutSec 60

                    $itterateobject = $env:FIRST_LEVEL_OBJECT
                
                    # Check if the response contains data
                    if ($response -and $response.$itterateobject) {
                        # Increment the counter for KVMs with entries
                        $KVMsWithEntriesCount++
                        # Store the KVM name with entries
                        $org_KVMsWithEntries_Success += $orgkvm

                        # Specify the fields you want to encrypt
                        $fieldsToEncrypt = $env:FieldValuestoEncrypt -split ","
                        
                        # Loop through the JSON data and encrypt specified fields
                        foreach ($entry in $response.$itterateobject) {
                            try {

                                # Call the Encrypt-Fields function to encrypt the specified fields
                                $entry = Encrypt-String -plaintext $entry.value
                                $entry.value = $entry
                            }
                            catch {
                                Write-Host "An error occurred: $_"
                            }
                        }
                        
                        # Convert the JSON data back to a string
                        $entry = $response | ConvertTo-Json -Depth 10

                        # Define the output file name based on environment variables
                        $fileName = "$($org)-$($orgkvm).json"
                        
                        # Save the encrypted data to the file
                        $response | Out-File -FilePath $fileName -Encoding UTF8
                        # Write-Host "org-kvm: $response"				
                    } else {
                        Write-Host "No data found in the response."

                        # Increment the counter for KVMs without entries
                        $KVMsWithoutEntriesCount++
                        # Add the KVM name to the array of KVMs without entries
                        $org_KVMsWithoutEntries_Success += $orgkvm
                    }
                }
                catch {
                    Write-Host "An error occurred: $_"
                    $org_KVMsWithEntries_Failure += $orgkvm
                    $org_KVMsWithoutEntries_Failure += $orgkvm

                }
            }

        }
        catch {
            Write-Host "An error occurred: $_"
        }
        if (($KVMsWithEntriesCount + $KVMsWithoutEntriesCount) -eq 0) {
            $allSummaries_Log += "Total Org KVMs Count - $($KVMsWithEntriesCount + $KVMsWithoutEntriesCount)`r`n"
        }
        else {
            
            # Append the KVM counts and names to the environment summary
            $KVMSummary += "Total Org KVMs Count - $($KVMsWithEntriesCount + $KVMsWithoutEntriesCount)`r`n"
            $KVMSummary += "Org KVMs With Entries, List - $($org_KVMsWithEntries_Success -join ', ')`r`n"
            $KVMSummary += "Org KVMs With Entries Count - $KVMsWithEntriesCount`r`n"
            $KVMSummary += "Org KVMs WithOut Entries Count - $KVMsWithoutEntriesCount`r`n"
            $KVMSummary += "Org KVMs WithOut Entries, List - $($org_KVMsWithEntries_Failure -join ', ')`r`n"
            # $KVMSummary += "KVMs with entries failed - $($org_KVMsWithEntries_Failure -join ', ')`r`n"
            # $KVMSummary += "KVMs without entries failed - $($org_KVMsWithoutEntries_Failure -join ', ')`r`n"

            # Append the environment summary to the allSummaries string
            $allSummaries_Log += $KVMSummary
        }

        # Reset the counters and arrays for the next environment
        $KVMsWithEntriesCount = 0
        $KVMsWithoutEntriesCount = 0
        $KVMsWithEntries = @()
        $KVMsWithoutEntries = @()

        cd ..
        $kvmpath = $baseURL+$org+"/keyvaluemaps"
        Invoke-RestMethod -Uri $kvmpath -Method:Get -Headers $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60 -OutFile "$org-kvms.json"

    # # ------------------------------------- Organization - Resources ----------------------------------------------------
    #     #create resource-named folder
    #     if(!(test-path -PathType container resources))
    #     {
    #         mkdir "resources"
    #         cd resources
    #     }
    #     else {
    #         cd resources
    #     }	

    #     # Initialize an array to store resources names
    #     $resourcesNames_Success = @()
    #     $resourcesNames_Failure = @()
    #     $resourcesCountIn_Success = 0
    #     $resourcesCountIn_Failed = 0

    #     try {
    #         #Get and stash org resources
    #         $resourcepath = $baseURL+$org+"/resourcefiles"
    #         $resources = Invoke-WebRequest -Uri $resourcepath -Method:Get -Headers  $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60 | ConvertFrom-Json
        
    #         foreach ($resource in $resources) {
    #             try {
    #                 $resourcesNames_Success += $resource.name
    #                 $resoourcetype = $resource.type
    #                 $resourcename = $resource.name
    #                 #Get and stash resource files
    #                 $resourcefilepath =  $baseURL+$org+"/resourcefiles/"+$resoourcetype+"/"+$resourcename
    #                 Invoke-WebRequest -Uri $resourcefilepath -Method:Get -Headers  $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60 -OutFile "$org-$resourcename-$resoourcetype.json"
    #             }
    #             catch{
    #             $resourcesNames_Failure += $resource.name
    #             }
    #         }

    #         $resourcesNamesList_Success =  $($resourcesNames_Success -join ', ')
    #         $resourcesNamesList_Failed =  $($resourcesNames_Failure -join ', ')

    #         $resourcesCountIn_Success = $resourcesNames_Success.Count
    #         $resourcesCountIn_Failed = $resourcesNames_Failure.Count

    #         $org_Resources_Log_Success = ("Org Resources Exported Successfully to GitHub: Count - $resourcesCountIn_Success, Resources List - $resourcesNamesList_Success`r`n") #: "Resources API Executed Successfully but no Data found in the Response.`r`n"
    #         $org_Resources_Log_Failed = ("Org Resources Export Failed: Count - $resourcesNamesList_Failed, Resources List - $resourcesNamesList_Failed`r`n") #: ""

    #         $allSummaries_Log += $org_Resources_Log_Success + $org_Resources_Log_Failed

    #         #back out of resrouce files folder
    #         cd..
            
    #     }
    #     catch [System.Net.WebException] {
    #         $errorResponse = $_.Exception.Response
    #         if ($errorResponse.StatusCode -eq [System.Net.HttpStatusCode]::NotFound) {
    #             # Handle the 404 error (HTTP Not Found) here, or simply do nothing to skip it
    #             Write-Host "API returned a 404 error. Skipping..."
    #         }
    #         else {
    #             # Handle other web exceptions here
    #             Write-Host "An error occurred: $($_.Exception.Message)"
    #         }
    #         cd ..
    #     }
    #     catch {
    #         # Handle other exceptions here
    #         Write-Host "An error occurred: $($_.Exception.Message)"
    #         cd ..
    #     }

    #     try {
    #         $resourcepath = $baseURL+$org+"/resourcefiles"
    #         Invoke-WebRequest -Uri $resourcepath -Method:Get -Headers $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60 -OutFile "$org-resources.json"
    #     }
    #     catch {
    #         Write-Host "An error occurred: $_"
    #     }
    # ---------------------------- Organization - API Products ----------------------------------------------------------
        if(!(test-path -PathType container apiproducts))
        {
            mkdir "apiproducts"
            cd apiproducts
        }
        else {
            cd apiproducts
        }

        # Initialize an array to store product names
        $productNames_Success = @()
        $productNames_Failure = @()
        $productCountIn_Success = 0
        $productCountIn_Failed = 0

        $productpath = $baseURL+$org+"/apiproducts"
        $apiproductsResponse = Invoke-RestMethod -Uri $productpath -Method:Get -Headers $headers -ContentType "application/json" -ErrorAction Stop -TimeoutSec 60

        foreach ($product in $apiproductsResponse.apiProduct) {
            try {
                $productNames_Success += $product.name
                $apiproductdetail = $baseURL+$org+"/apiproducts/"+$($product.name)
                Invoke-RestMethod -Uri $apiproductdetail -Method Get -Headers $headers -ContentType "application/json" -ErrorAction Stop -TimeoutSec 60 -OutFile "$($product.name).json"
            }
            catch{
                $productNames_Failure += $product.name
            } 
        }   
        cd ..

        $productNamesList_Success =  $($productNames_Success -join ', ')
        $productNamesList_Failed =  $($productNames_Failure -join ', ')

        $productCountIn_Success = $productNames_Success.Count
        $productCountIn_Failed = $productNames_Failure.Count

        $product_Log_Success = ("Products Exported Successfully to GitHub: Count - $productCountIn_Success, Products List - $productNamesList_Success`r`n") #: "Products API Executed Successfully but no Data found in the Response.`r`n"
        $product_Log_Failed = ("Products Export Failed: Count - $productCountIn_Failed, Products List - $productNamesList_Failed`r`n") #: ""

        $allSummaries_Log += $product_Log_Success + $product_Log_Failed
        
        Invoke-RestMethod -Uri $productpath -Method:Get -Headers $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60 -OutFile "$org-apiproducts.json"
        $APIPRODUCTSTATIC = "API Products are Exported Successfully to GitHub."

    # ----------------------------- Organization - Developers -----------------------------------------------------------
        if(!(test-path -PathType container developers))
        {
            mkdir "developers"
            cd developers
        }
        else {
            cd developers
        }

         # Initialize an array to store Developers
        $developermailid_Success = @()
        $developermailid_Failure = @()
        $developersCountIn_Success = 0
        $developersCountIn_Failed = 0

        $developerpath = $baseURL+$org+"/developers"
        $developer = Invoke-RestMethod -Uri $developerpath -Method:Get -Headers $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60


        foreach ($developerItem in $developer.developer) {
            try {
                $developermailid_Success += $developerItem.email
                $developerdetail = $baseURL + $org + "/developers/" + $($developerItem.email)
                Invoke-RestMethod -Uri $developerdetail -Method:Get -Headers $headers -ContentType "application/json" -ErrorAction Stop -TimeoutSec 60 -OutFile "$($developerItem.email).json"
            }
            catch{
                $developermailid_Failure += $developerItem.email
            }
        }
        cd ..

        $developermailidList_Success =  $($developermailid_Success -join ', ')
        $developermailidList_Failed =  $($developermailid_Failure -join ', ')

        $developersCountIn_Success = $developermailid_Success.Count
        $developersCountIn_Failed = $developermailid_Failure.Count

        $developer_Log_Success = ("Developers Exported Successfully to GitHub: Count - $developersCountIn_Success, Developers List - $developermailidList_Success`r`n") #: "Developers API Executed Successfully but no Data found in the Response.`r`n"
        $developer_Log_Failed = ("Developers Export Failed: Count - $developersCountIn_Failed, Developers List - $developermailidList_Failed`r`n")# : ""

        $allSummaries_Log += $developer_Log_Success + $developer_Log_Failed

        Invoke-RestMethod -Uri $developerpath -Method:Get -Headers $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60 -OutFile "$org-developers.json"

    # ------------------------------ Organization - Apps ----------------------------------------------------------------
        
		# Check if the "apps" directory exists, and create it if not
		if (!(Test-Path -PathType Container apps)) {
		    mkdir "apps"
		    cd apps
		}
		else {
		    cd apps
		}

        # Initialize an array to store app names
        $appNames_Success = @()
        $appNames_Failure = @()
        $appCountIn_Success = 0
        $appCountIn_Failed = 0
		
		# Get and stash apps
		Write-Host "Getting apps, inside the app folder..."
		
		# Make the API call to get the list of apps
		$AppsEndpoint = $baseURL + $org + "/apps"
		try {
		    $appList = Invoke-RestMethod -Uri $AppsEndpoint -Method Get -Headers $headers
		
		    # Check if the API call was successful and the response contains app data
		    if ($appList -ne $null -and $appList.app.Count -gt 0) {
		
		        # Loop through each app object in the response
		        foreach ($app in $appList.app) {
		
		            # Extract app details
		            $appId = $app.appId
		
		            # Make the API call to get app details by app ID
		            $AppDetailsEndpoint = $baseURL + $org + "/apps/" + $appId
		            try {
		                $appDetailResponse = Invoke-RestMethod -Uri $AppDetailsEndpoint -Method:Get -Headers $headers
				  		$Appdata = $appDetailResponse | ConvertTo-JSON -Depth 10
		
		                if ($appDetailResponse -ne $null) {
		                    $appDetail = $appDetailResponse.app
		                    $appName = $appDetailResponse.name

                            $appNames_Success += $appName
		
		                    # Check if credentials are not null and not empty
		                    if ($appDetailResponse.credentials -ne $null -and $appDetailResponse.credentials.Count -gt 0) {
		                        # Specify the fields you want to encrypt
		                        $appfields = "consumerKey", "consumerSecret"
		                        $encryptedFields = @{}
		
		                        # Loop through the specified fields and encrypt their values
		                        foreach ($field in $appfields) {
		                            $plaintext = $appDetailResponse.credentials[0].$field
		                            $encryptedData = Encrypt-String -plaintext $plaintext -key $keyAES
		                            $appDetailResponse.credentials[0].$field = $encryptedData
		                        }
		                    }
		                    else {
		                        Write-Host "No credentials found for app with ID $appId."
		                    }
		
		                    # Display the modified JSON data with only encrypted values
		                    $encryptedJsonData = $appDetailResponse | ConvertTo-Json -Depth 30
					  		# Write-Host "EncryptedJSONData: $encryptedJsonData"
		
		                    # Define the output file name based on the app ID
		                    $fileName = "$org-$appName.json"
		
		                    # Save the encrypted data to the file
		                    $encryptedJsonData | Out-File -FilePath $fileName -Encoding UTF8
		
		                }
		                else {
		                    Write-Host "App with ID $appId not found."
		                }
		            }
		            catch {
		                Write-Host "An error occurred while fetching app details for ID $appId $_"
                        $appNames_Failure += $appName
		            }
		        }
		    }
		    else {
		        Write-Host "No apps found in the response."
		    }
		}
		catch {
		    Write-Host "An error occurred while fetching the list of apps: $_"
		}
		cd ..

        
        $appNamesList_Success =  $($appNames_Success -join ', ')
        $appNamesList_Failed =  $($appNames_Failure -join ', ')

        $appCountIn_Success = $appNames_Success.Count
        $appCountIn_Failed = $appNames_Failure.Count

        $app_Log_Success = ("Apps Exported Successfully to GitHub: Count - $appCountIn_Success, Apps List - $appNamesList_Success`r`n")# : "Apps API Executed Successfully but no Data found in the Response.`r`n"
        $app_Log_Failed = ("Apps Export Failed: Count - $appCountIn_Failed, Apps List - $appNamesList_Failed`r`n")# : ""
       
        $allSummaries_Log += $app_Log_Success + $app_Log_Failed

    # ------------------------------ Organization - Master Deployment Proxies -------------------------------------------
        $masterDeploymentPath = $baseURL+$org+"/deployments"
        $masterDeployments = Invoke-RestMethod -Uri $masterDeploymentPath -Method:Get -Headers $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60 -OutFile "$org-master-proxy-deployments.json"

        $ORG_MASTER_DEPLOYMENT = "Organization Master Proxy Deployment Exported Successfully to GitHub.`r`n"
        $allSummaries_Log += $ORG_MASTER_DEPLOYMENT

#     # ----------------------------- Organization - Environment Start ----------------------------------------------------
        if(!(test-path -PathType container environments)){
            mkdir "environments"
            cd environments
        }
        else {
            cd environments
        }

        $envpath = $baseURL+$org+"/environments"
        $environments = Invoke-RestMethod -Uri $envpath -Method:Get -Headers $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60
        Invoke-RestMethod -Uri $envpath -Method:Get -Headers $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60  -OutFile "environments.json"

        # Combine the current directory path with the file name
        $filePath = Join-Path -Path $PWD -ChildPath $summary_file_name

        # Use New-Item to create the file
        New-Item -Path $filePath -ItemType File

        # Read the list of environments from environments.json
        $environments = Get-Content -Raw -Path "environments.json" | ConvertFrom-Json

        # Join the array elements with commas and print as a single comma-separated string
        $environmentNames = $environments -join ", "
        $environmentCount = $($environments.Count)

        $environment_Success = "Environments: Count - $environmentCount, Environments List - $environmentNames`r`n"
       
        $allSummaries_Log += $environment_Success

        # -------- Loop through each environment -----------------------------------
         foreach ($env in $environments) {

            if(!(test-path -PathType container $env)){
                mkdir "$env"
                cd $env
            }
            else {
                cd $env
            }

            # Initialize the environment summary for this iteration
            $envSummary = "Environment - $env`r`n" 
            
            # -------------------------------- Environment - KVMs -----------------------------------------------------

                try {
                    $kvmpathenv = $baseURL + $org + "/environments/" + $env + "/keyvaluemaps"
                    $envkvms = Invoke-RestMethod -Uri $kvmpathenv -Method:Get -Headers $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60

                    if (!(Test-Path -PathType Container kvms)) {
                        mkdir "kvms"
                        cd kvms
                    }
                    else {
                        cd kvms
                    }

                    # Initialize counters for KVMs with and without entries
                    $KVMsWithEntriesCount = 0
                    $KVMsWithoutEntriesCount = 0

                    $KVMsWithEntries = @()
                    $KVMsWithoutEntries = @()

                    foreach ($envkvm in $envkvms) {

                        $kvmpthtestpath = "https://apigee.googleapis.com/v1/organizations/" + $org + "/environments/" + $env + "/keyvaluemaps/" + $envkvm + "/entries"

                        $response = Invoke-RestMethod -Uri $kvmpthtestpath -Method:Get -Headers $headers -ContentType "application/json" -ErrorAction Stop -TimeoutSec 60
                        $kvmentries = $response | ConvertTo-JSON -Depth 10  # Convert to JSON with a higher depth to preserve nested structures
                        $kvmentries = $kvmentries | ConvertFrom-Json

                        # Check if the response contains data
                        if ($kvmentries -and $kvmentries.Count -gt 0) {

                            # Increment the counter for KVMs with entries
                            $KVMsWithEntriesCount++
                            # Store the KVM name with entries
                            $KVMsWithEntries += $envkvm

							# Create a new custom object to store the encrypted data
				       		$encryptedEntries = @()

                            # Loop through the KVM entries and encrypt specified fields
                            foreach ($entry in $kvmentries.keyValueEntries) {
                                try {
									$plaintext = $entry.value
									$encryptedData = Encrypt-String -plaintext $plaintext -key $keyAES
    								$entry.value = $encryptedData
                                    
                                    # Add the encrypted entry to the array
                                    $encryptedEntries += $entry
                                }
                                catch {
                                    Write-Host "An error occurred: $_"
                                }
                            }
							$kvmentries.keyValueEntries = $encryptedEntries

                            # To save the data to a file
                            $fileName = "$org-$env-$envkvm-kvm-values.json"
                            $kvmentries | ConvertTo-Json -Depth 10 | Out-File -FilePath $fileName -Encoding UTF8

                        } else {
                            Write-Host "No data found in the response for $($envkvm). Skipping..."
                            # Increment the counter for KVMs without entries
                            $KVMsWithoutEntriesCount++
                            # Add the KVM name to the array of KVMs without entries
                            $KVMsWithoutEntries += $envkvm
                        }
                    }

                    # Append the KVM counts and names to the environment summary
                    $envSummary += "Total KVMs Count: $($KVMsWithEntriesCount + $KVMsWithoutEntriesCount)`r`n"
                    $envSummary += "KVMs With Entries: List- $($KVMsWithEntries -join ', ')`r`n"
                    $envSummary += "KVMs With Entries: Count- $KVMsWithEntriesCount`r`n"
                    $envSummary += "KVMs Without Entries: Count- $KVMsWithoutEntriesCount`r`n"
                    $envSummary += "KVMs Without Entries: List- $($KVMsWithoutEntries -join ', ')`r`n"

                    # Append the environment summary to the allSummaries string
                    $allSummaries_Log += $envSummary

                    # Reset the counters and arrays for the next environment
                    $KVMsWithEntriesCount = 0
                    $KVMsWithoutEntriesCount = 0
                    $KVMsWithEntries = @()
                    $KVMsWithoutEntries = @()
                }
                catch {
                    Write-Host "An error occurred: $_"
                }
                cd .. # for exit from kvm name folder
		# -------------------------------- Environment - Targetservers --------------------------------------------
                if(!(test-path -PathType container target-servers)){
                    mkdir "target-servers"
                    cd target-servers
                }
                else {
                    cd target-servers
                }

                # Initialize an array to store proxy names
                $targetserverNames_Success = @()
                $targetserverNames_Failure = @()
                $targetserverCountIn_Success = 0
                $targetserverCountIn_Failed = 0

                $targetserverpathenv = $baseURL+$org+"/environments/"+$($env)+"/targetservers"
                $envtargetserver = Invoke-RestMethod -Uri $targetserverpathenv -Method:Get -Headers $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60

                
                foreach ($value in $($envtargetserver)) {
                    try {
                        $targetserverNames_Success += $value
                        $targetserverpathenv2 = $targetserverpathenv+"/"+$value
                        $envtargetserver = Invoke-RestMethod -Uri $targetserverpathenv2 -Method:Get -Headers $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60 -OutFile "$org-$env-($value).json"
                    }
                    catch {
                        Write-Host "An error occurred: $_"
                        $targetserverNames_Failure += $value
                    }
                }

                $targetserverNamesList_Success =  $($targetserverNames_Success -join ', ')
                $targetserverNamesList_Failed =  $($targetserverNames_Failure -join ', ')

                $targetserverCountIn_Success = $targetserverNames_Success.Count
                $targetserverCountIn_Failed = $targetserverNames_Failure.Count

                $env_TargetServer_Log_Success = "Environment Target-Servers Exported Successfully to GitHub: Count - $targetserverCountIn_Success, Target-Servers Names - $targetserverNamesList_Success`r`n"
                $env_TargetServer_Log_Failed = ("Environment Target-Servers Export Failed: Count - $targetserverCountIn_Failed, Target-Servers Names - $targetserverNamesList_Failed`r`n") #: ""

                $allSummaries_Log += $env_TargetServer_Log_Success + $env_TargetServer_Log_Failed
            
                cd ..
                $targetserverpathenv = $baseURL+$org+"/environments/"+$($env)+"/targetservers"
                Invoke-RestMethod -Uri $targetserverpathenv -Method:Get -Headers $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60 -OutFile "$org-$env-targetservers.json"

            # -------------------------------- Environment - keystores ------------------------------------------------
                $keystorepathenv = $baseURL+$org+"/environments/"+$($env)+"/keystores"
                Invoke-RestMethod -Uri $keystorepathenv -Method:Get -Headers $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60 -OutFile "$org-keystores.json"
                $envkeystores = Invoke-RestMethod -Uri $keystorepathenv -Method:Get -Headers $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60
                
                # Initialize an array to store sharedflow names
                $env_KeyStoreNames_Success = @()
                $env_KeyStoreNames_Failure = @()
                $env_KeyStoreCountIn_Success = 0
                $env_KeyStoreCountIn_Failed = 0

                foreach ($envkeystore in $envkeystores) {
                    if(!(test-path -PathType container keystores)){
                        mkdir "keystores"
                        cd keystores
                    }
                    else {
                        cd keystores
                    }

                    try {
                        $env_KeyStoreNames_Success += $envkeystore
                        # Define the keystore response path
                        $keystoreresponse = $baseURL+$org+"/environments/"+$env+"/keystores/"+$envkeystore

                        # Retrieve keystore response and save to a JSON file
                        $keystoreresponse1 = Invoke-RestMethod -Uri $keystoreresponse -Method:Get -Headers $headers -ContentType "application/json" -ErrorAction Stop -TimeoutSec 60 -OutFile "$envkeystore.json"
                    }
                    catch{
                        $env_KeyStoreNames_Failure += $envkeystore
                    }

                    cd ..

                    # Initialize an array to store env_aliases
                    $env_aliasesNames_Success = @()
                    $env_aliasesNames_Failure = @()
                    $env_aliasesCountIn_Success = 0
                    $env_aliasesCountIn_Failed = 0

                    $keystorealiases =  $baseURL+$org+"/environments/"+$($env)+"/keystores/"+$envkeystore+"/aliases"
                    $aliasesdetials = Invoke-WebRequest -Uri $keystorealiases -Method:Get -Headers  $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60
                    # Your JSON array as a string
                    $jsonData = $aliasesdetials
                    
                    # Parse the JSON array
                    $data = $jsonData | ConvertFrom-Json
                    
                    # Use a foreach loop to extract each value
                    foreach ($value in $data) {
                        if (!(Test-Path -PathType Container aliases)) {
                            mkdir "aliases"
                            cd aliases
                        }
                        else {
                            cd aliases
                        }

                        try {
                            $env_aliasesNames_Success += $value

                            if(!(test-path -PathType container $value)){
                                mkdir "$value"
                                cd $value
                            }
                            else {
                                cd $value
                            }
                            $keystorealiasedetail =  $baseURL+$org+"/environments/"+$($env)+"/keystores/"+$envkeystore+"/aliases/"+$value
                            Invoke-WebRequest -Uri $keystorealiasedetail -Method:Get -Headers  $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60 -OutFile "$org-aliases-$value.json"
                            
                            $keystorealiasecertificate =  $baseURL+$org+"/environments/"+$($env)+"/keystores/"+$envkeystore+"/aliases/"+$value+"/certificate"
                            # Invoke-WebRequest -Uri $keystorealiasecertificate -Method:Get -Headers  $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60 -OutFile "$value-certificate.json"
                            
                            # Retrieve the key content
                            $certContent = Invoke-RestMethod -Uri $keystorealiasecertificate -Method:Get -Headers $headers -ContentType "application/json" -ErrorAction Stop -TimeoutSec 60

                            # Convert the key content to bytes
					        $keyContentBytes = [System.Text.Encoding]::UTF8.GetBytes($certContent)

                            $encryptedCertData = Encrypt-String -plaintext $keyContentBytes -key $keyAES

                            # Define the output file name
                            $certFileName = "$org-aliases-$value-certificate.json"

                            # Save the JSON data to the file
                            $encryptedCertData | Out-File -FilePath $certFileName -Encoding UTF8
                        }
                        catch{
                            $env_aliasesNames_Failure += $value
                        }
                        # Write-Host "Encrypted key content has been saved to $fileName."
                        cd .. 
                        cd ..
                    } 
                }

                # Count the total number of keystores
                $env_KeyStoreNamesList_Success =  $($env_KeyStoreNames_Success -join ', ')
                $env_KeyStoreNamesList_Failed =  $($env_KeyStoreNames_Failure -join ', ')

                $env_KeyStoreCountIn_Success = $env_KeyStoreNames_Success.Count
                $env_KeyStoreCountIn_Failed = $env_KeyStoreNames_Failure.Count

                $env_KeyStore_Log_Success = ("Environment KeyStore Exported Successfully to GitHub: Count - $env_KeyStoreCountIn_Success, KeySores List - $env_KeyStoreNamesList_Success`r`n") #: "Environment KeyStore API Executed Successfully but no Data found in the Response.`r`n"
                $env_KeyStore_Log_Failed =  ("Environment KeyStore Export Failed: Count - $env_KeyStoreCountIn_Failed, KeySores List - $env_KeyStoreNamesList_Failed`r`n") #: ""

                $allSummaries_Log += $env_KeyStore_Log_Success + $env_KeyStore_Log_Failed

                # Count the total number of Aliases

                $env_aliasesNamesList_Success =  $($env_aliasesNames_Success -join ', ')
                $env_aliasesNamesList_Failed =  $($env_aliasesNames_Failure -join ', ')

                $env_aliasesCountIn_Success = $env_aliasesNames_Success.Count
                $env_aliasesCountIn_Failed = $env_aliasesNames_Failure.Count

                $env_aliases_Log_Success = ("Environment Aliases Exported Successfully to GitHub: Count - $env_aliasesCountIn_Success, Aliases List - $env_aliasesNamesList_Success`r`n") #: "Environment Aliases API Executed Successfully but no Data found in the Response.`r`n"
                $env_aliases_Log_Failed = ("Environment Aliases Export Failed: Count - $env_aliasesCountIn_Failed, Aliases List - $env_aliasesNamesList_Failed`r`n") #: ""

                $allSummaries_Log += $env_aliases_Log_Success + $env_aliases_Log_Failed

            # -------------------------------- Environment - caches ---------------------------------------------------
                
                $cachepathenv = $baseURL+$org+"/environments/"+$($env)+"/caches"
                Invoke-RestMethod -Uri $cachepathenv -Method:Get -Headers $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60 -OutFile "$org-$env-caches.json"
                $envcaches = Invoke-RestMethod -Uri $cachepathenv -Method:Get -Headers $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60
                
                # Initialize an array to store caches
                $caheNames_Success = @()
                $caheNames_Failure = @()
                $caheCountIn_Success = 0
                $caheCountIn_Failed = 0

                if(!(test-path -PathType container caches)){
                    mkdir "caches"
                    cd caches
                }
                else {
                    cd caches
                }
                foreach ($envca in $envcaches) {
                    try {
                        $caheNames_Success += $envca

                        $cacheenvdetails = $baseURL+$org+"/environments/"+$($env)+"/caches/"+$envca
                        Invoke-RestMethod -Uri $cacheenvdetails -Method:Get -Headers $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60 -OutFile "$org-$env-$envca.json"
                    }
                    catch{
                        $caheNames_Failure += $envca
                    } 

                }
                $cacheNamesList_Success =  $($caheNames_Success -join ', ')
                $cacheNamesList_Failed =  $($caheNames_Failure -join ', ')

                $cacheCountIn_Success = $caheNames_Success.Count
                $cacheCountIn_Failed = $caheNames_Failure.Count

                $env_cache_Log_Success = ("Environment Caches Exported Successfully to GitHub: Count - $cacheCountIn_Success, Caches List - $cacheNamesList_Success`r`n") #: "Caches API Executed Successfully but no Data found in the Response.`r`n"
                $env_cache_Log_Failed = ("Environment Caches Exported Export Failed: Count - $cacheCountIn_Failed, Caches List - $cacheNamesList_Failed`r`n") #: ""

                $allSummaries_Log += $env_cache_Log_Success + $env_cache_Log_Failed

                cd ..
                
               
            # -------------------------------- Environment - flowhooks ------------------------------------------------
                # Set the base directory path
                $baseDirectory = "flowhooks"
                
                # Check if the base directory exists, and create it if not
                if (!(Test-Path -PathType Container $baseDirectory)) {
                    mkdir $baseDirectory
                }
                # Initialize an array to store flowhooks
                $flowhookNames_Success = @()
                $flowhookNames_Failure = @()
                $flowhookCountIn_Success = 0
                $flowhookCountIn_Failed = 0
                
                $flowhookpathenv = $baseURL+$org+"/environments/"+$env+"/flowhooks"
                Invoke-RestMethod -Uri $flowhookpathenv -Method Get -Headers $headers -ContentType "application/json" -ErrorAction Stop -TimeoutSec 60 -OutFile "$baseDirectory\$org-flowhook.json"
                
                # Load the JSON data from the file
                $flowhookdetail = Get-Content "$baseDirectory\$org-flowhook.json" | ConvertFrom-Json
                
                
                # Iterate through each value in the response
                foreach ($value in $flowhookdetail) {
                    try {
                        $flowhookNames_Success += $value
                        $flowhookpathdetail = $baseURL + $org + "/environments/" + $env + "/flowhooks/" + $value
                        Invoke-RestMethod -Uri $flowhookpathdetail -Method Get -Headers $headers -ContentType "application/json" -ErrorAction Stop -TimeoutSec 60 -OutFile "$baseDirectory\$value.json"
                    }
                    catch{
                        $flowhookNames_Failure += $value
                    } 
                }

                $flowhookNamesList_Success =  $($flowhookNames_Success -join ', ')
                $flowhookNamesList_Failed =  $($flowhookNames_Failure -join ', ')

                $flowhookCountIn_Success = $flowhookNames_Success.Count
                $flowhookCountIn_Failed = $flowhookNames_Failure.Count

                $env_FlowHook_Log_Success = ("Environment FlowHooks Exported Successfully to GitHub: Count - $flowhookCountIn_Success, FlowHook List - $flowhookNamesList_Success`r`n")# : "FlowHooks API Executed Successfully but no Data found in the Response.`r`n"
                $env_FlowHook_Log_Failed = ("Environment FlowHooks Exported Export Failed: Count - $flowhookCountIn_Failed, FlowHook List - $flowhookNamesList_Failed`r`n") #: ""

                $allSummaries_Log += $env_FlowHook_Log_Success + $env_FlowHook_Log_Failed
                
                # Remove the directory and its contents if it exists
                Remove-Item -Path "$baseDirectory\$org-flowhook.json" -Recurse

            # -------------------------------- Environment - Proxies --------------------------------------------------
                if(!(test-path -PathType container proxies)){
                    mkdir "proxies"
                    cd proxies
                }
                else {
                    cd proxies
                }

                # Initialize an array to store proxy names
                $envproxyNames_Success = @()
                $envproxyNames_Failure = @()
                $envproxyCountIn_Success = 0
                $envproxyCountIn_Failed = 0

                $proxypathenv = $baseURL+$org+"/environments/"+$($env)+"/deployments"
                Invoke-RestMethod -Uri $proxypathenv -Method:Get -Headers $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60 -OutFile "$env-proxies.json"

                # Load the JSON data from the file
                $jsonData = Get-Content -Path "$env-proxies.json" | ConvertFrom-Json

                # Extract the apiproxy and revision values
                $deployments = $jsonData.deployments
                foreach ($deployment in $deployments) {
                    $apiproxy = $deployment.apiProxy
                    $revision = $deployment.revision
                    if(!(test-path -PathType container $($apiproxy))){
                        mkdir -p "$apiproxy"
                        cd $apiproxy
                    }
                    else {
                        cd $apiproxy
                    }

                    try {
                        $envproxyNames_Success += $apiproxy

                        if(!(test-path -PathType container $revision)){
                            mkdir -p "$revision"
                            cd $revision
                        }
                        else {
                            cd $revision
                        }

                        # Output the extracted values
                        $path2 = $baseURL+$org+"/environments/"+$($env)+"/apis/"+$apiproxy+"/revisions/"+$revision+"/deployments"
                        Invoke-RestMethod -Uri $path2 -Method:Get -Headers $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60 -OutFile "$org-$env-proxy-$($apiproxy)-deployment-rev$revision.json"

	  					$caches_api = $baseURL+$org+"/environments/"+$($env)+"/apis/"+$apiproxy+"/revisions/"+$revision
                        $caches_api_response = Invoke-RestMethod -Uri $caches_api -Method:Get -Headers $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60
                        Invoke-RestMethod -Uri $caches_api -Method:Get -Headers $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60 -OutFile "$($apiproxy)-cachedetails-rev$revision.json"
                        Write-Host "CacheResponse: $caches_api_response"
                    }
                    catch{
                        $envproxyNames_Failure += $apiproxy
                    }

                    cd ..
                    cd ..
                }

                $envproxyNamesList_Success =  $($envproxyNames_Success -join ', ')
                $envproxyNamesList_Failed =  $($envproxyNames_Failure -join ', ')

                $envproxyCountIn_Success = $envproxyNames_Success.Count
                $envproxyCountIn_Failed = $envproxyNames_Failure.Count

                $env_Proxy_Log_Success = ("Environment Proxies Exported Successfully to GitHub: Count - $envproxyCountIn_Success, Environment Proxy Names - $envproxyNamesList_Success`r`n")# : "Environment Proxies API Executed Successfully but no Data found in the Response.`r`n"
                $env_Proxy_Log_Failed = ("Environment Proxies Export Failed: Count - $envproxyCountIn_Failed, Environment Proxy Names - $envproxyNamesList_Failed`r`n") #: ""

                $allSummaries_Log += $env_Proxy_Log_Success + $env_Proxy_Log_Failed
                
                cd ..

            # ---------------------------------Environment - Sharedflows ----------------------------------------------

                # Initialize an array to store proxy names
                $envSharedFlowNames_Success = @()
                $envSharedFlowNames_Failure = @()
                $envSharedFlowCountIn_Success = 0
                $envSharedFlowCountIn_Failed = 0


                if(!(test-path -PathType container shared-flows)){
                    mkdir "shared-flows"
                    cd shared-flows
                }
                else {
                    cd shared-flows
                }

                try {
                    $sharedflowpath = $baseURL+$org+"/sharedflows"
                    $sharedflows = Invoke-RestMethod -Uri $sharedflowpath -Method:Get -Headers $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60
                    Invoke-RestMethod -Uri $sharedflowpath -Method:Get -Headers $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60 -OutFile "sharedflows.json"
                }
                catch {
                    Write-Host "An error occurred at: $_"
                    $ENVSHARED_FLOW = "Environment Sharedflows Expported Successfully to Github.`r`n"
                    $allSummaries_Log += $ENVSHARED_FLOW
                }

                try {
                    if ($sharedflows.sharedFlows -is [array]) {
                        # Iterate through each shared flow name
                        foreach ($sharedFlow in $sharedflows.sharedFlows) {
                            $sharedFlowName = $sharedFlow.name
                            $envSharedFlowNames_Success += $sharedFlowName

                            if(!(test-path -PathType container $sharedFlowName)){
                                mkdir "$sharedFlowName"
                                cd $sharedFlowName
                            }
                            else {
                                cd $sharedFlowName
                            }
                            # Write-Host "sharedFlowName:$sharedFlowName"
                            $flowDetailpath = "https://apigee.googleapis.com/v1/organizations/$org/sharedflows/$sharedFlowName"
                            $flowDetail = Invoke-RestMethod -Uri $flowDetailpath -Method:Get -Headers $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60
                            # $data = ConvertFrom-Json $flowDetail
                            foreach ($revision in $flowDetail.revision) {
                                # Write-Host "Enterned into REVISION LOOP...!"
                                if(!(test-path -PathType container $revision)){
                                    mkdir -p "$revision"
                                    cd $revision
                                }
                                else {
                                    cd $revision
                                }
                                try{
                                    $flowDetailRevpath = "https://apigee.googleapis.com/v1/organizations/"+$org+"/environments/"+$env+"/sharedflows/"+$sharedFlowName+"/revisions/"+$revision+"/deployments"
                                    $flowDetailRev = Invoke-RestMethod -Uri $flowDetailRevpath -Method:Get -Headers $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60 -OutFile "$org-$env-sharedflow-$sharedFlowName-deployment-rev$revision.json"
                                }
                                catch {
                                    # Write-Host "An error occurred: $_"
                                }
                                cd .. #revision folder
                                
                            }
                            cd .. #individual sharedflow folder
                        }
                    }
                    else {
                        Write-Host "No 'sharedFlows' array found in the JSON data."
                    }
                }
                
                catch {
                    $envSharedFlowNames_Failure += $sharedFlowName                   
                }

                $envSharedFlowNamesList_Success =  $($envSharedFlowNames_Success -join ', ')
                $envSharedFlowNamesList_Failed =  $($envSharedFlowNames_Failure -join ', ')

                $envSharedFlowCountIn_Success = $envSharedFlowNames_Success.Count
                $envSharedFlowCountIn_Failed = $envSharedFlowNames_Failure.Count

                $env_SharedFlow_Log_Success = ("Environment SharedFlows Exported Successfully to GitHub: Count - $envSharedFlowCountIn_Success, Environment SharedFlow Names - $envSharedFlowNamesList_Success`r`n")# : "Environment Proxies API Executed Successfully but no Data found in the Response.`r`n"
                $env_SharedFlow_Log_Failed = ("Environment SharedFlows Export Failed: Count - $envSharedFlowCountIn_Failed, Environment SharedFlow Names - $envSharedFlowNamesList_Failed`r`n") #: ""

                $allSummaries_Log += $env_SharedFlow_Log_Success + $env_SharedFlow_Log_Failed

              cd ..

                # -------------------------------- Environment - Resource Files -------------------------------------------
                try {
	                $resourcefilespathenv = $baseURL+$org+"/environments/"+$($env)+"/resourcefiles"
	                Invoke-RestMethod -Uri $resourcefilespathenv -Method:Get -Headers $headers -ContentType "application/json" -ErrorAction:Stop -TimeoutSec 60 -OutFile "$org-$($env)-resourcefiles.json"
	                
	                
	                $RESOURCE_FILES = "Environment Resource Files Exported Successfully to GitHub.`r`n"
	                $allSummaries_Log += $RESOURCE_FILES
				 }
	 			catch{
                    Write-Host "An error occurred resource files not found for the $($env)"
                    }
   		

            cd .. 
              
         }

        # -------- Write Logs after all environments executed ----------------------

            # Write the combined summaries to the summary file
            $allSummaries_Log | Out-File -FilePath $filePath -Append -Encoding UTF8
            
            cd .. #for exit from env folder
            
            cd .. #for exit from org folder


