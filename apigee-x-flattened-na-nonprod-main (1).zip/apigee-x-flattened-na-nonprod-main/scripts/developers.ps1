Param (
    [Parameter(mandatory = $true)][string]$AccessToken, # To receive GCP access token
    [Parameter(mandatory = $true)][string]$Org, # To receive Apigee Organization where action will be performed      
    [Parameter(mandatory = $true)][string]$Action, # To receive type of Action script shall perform
    [Parameter(mandatory = $false)][string]$Developeremail, # To receive Target Server name on which Action will be performed
    [Parameter(mandatory = $false)][string]$AdhocJsonBody # To receive JSON body for Create or Update Action
)

# Load utility functions
. "$PSScriptRoot\utilities.ps1"

# Set Variables 
$headers = @{Authorization = "Bearer $AccessToken" }
if ( $Action -ne "Delete") {
    $sourceOrg = Get-SourceOrg -targetOrg $Org  #call utility function from utilities script
    $DeveloperDirectory = "./$sourceOrg/developers"
    Set-Location $DeveloperDirectory
    $files = Get-ChildItem *.json
}

$apigeeDomain = "https://apigee.googleapis.com/v1/organizations/$Org/developers"

$DeveloperemailValid = ![string]::IsNullOrEmpty($Developeremail) -And ![string]::IsNullOrWhitespace($Developeremail) -And $Developeremail -ne "null"
$adhocJsonDataValid = ![string]::IsNullOrEmpty($AdhocJsonBody) -And ![string]::IsNullOrWhitespace($AdhocJsonBody) -And $AdhocJsonBody -ne "null"
$Developeremail = $Developeremail.ToLower()

if ( $Action -eq "ImportAll" ) {
    Write-Host "Importing Developers"
    $successCount = 0
    $failureCount = 0
    $failedDeveloperName = @()
    foreach ($file in $files ) {
        $requestPayload = Get-Content $file | ConvertFrom-Json
        $json_template = @"
{
  "apps" : ['$($requestPayload.apps -join "','")'],
  "companies" : [$($requestPayload.companies)],
  "email" : "$($requestPayload.email.ToLower())",
  "developerId" : "$($requestPayload.developerId)",
  "firstName" : "$($requestPayload.firstName)",
  "lastName" : "$($requestPayload.lastName)",
  "userName" : "$($requestPayload.userName)",
  "organizationName" : "$($requestPayload.organizationName)",
  "status" : "$($requestPayload.status)",
  "attributes" :[$($requestPayload.attributes)]
 
}
"@
        $reqPayload = $json_template
        Write-Host $reqPayload
		
        try { 
            Invoke-WebRequest -Uri $apigeeDomain -Method 'POST' -ContentType 'application/json; charset=utf-8' -Body $reqPayload -Headers $headers | Select-Object -Expand Content
            $successCount++
        }
        catch {
            # Handle any other exceptions that may occur
            Write-Host "An error occurred while importing Developer $($requestPayload.email) : $_"
            $failureCount++
            $failedDeveloperName += $($requestPayload.email)
        }
    }
    $summary = "Developers Import All:- Total $($successCount + $failureCount) Succeeded $successCount Failed $failureCount. Failed Developer Names $($failedDeveloperName -join ",")"
    if ( $failureCount -gt 0 ) {
        Write-Error $summary
    }
    else {
        Write-Host $summary
   }
}
elseif ( $Action -eq "Create" -And !$adhocJsonDataValid ) {
    if ( $DeveloperemailValid ) { 
        foreach ($file in $files ) {
            $requestPayload = Get-Content $file | ConvertFrom-Json
            $email = $requestPayload.email.ToLower()
            $firstname = $requestPayload.firstname
            $lastname = $requestPayload.lastname
            $username = $requestPayload.username
            $Developeremail = $Developeremail.ToLower()
            if ( $email -eq $Developeremail) {
                Write-Host "Creating Developer $Developeremail"
                $json_template = @{
                    "email"     = $email
                    "firstName" = $firstname
                    "lastName"  = $lastname
                    "userName"  = $username
                }
                $reqPayload = $json_template | ConvertTo-Json
                Write-Host $reqPayload
	
                Invoke-WebRequest -Uri $apigeeDomain -Method 'POST' -ContentType 'application/json; charset=utf-8' -Body $reqPayload -Headers $headers | Select-Object -Expand Content
            } 
        }
    }
    else {
        Write-Error "Developer Email Required For Create Action"
   	}
}
elseif ( $Action -eq "Update" -And !$adhocJsonDataValid ) {
    if ( $DeveloperemailValid ) {
        foreach ($file in $files ) {
            $requestPayload = Get-Content $file | ConvertFrom-Json
            $email = $requestPayload.email.ToLower()
            $firstname = $requestPayload.firstname
            $lastname = $requestPayload.lastname
            $username = $requestPayload.username
            $status = $requestPayload.status
            $Developeremail = $Developeremail.ToLower()
            Write-Host $email
            if ( $email -eq $Developeremail ) {
                Write-Host "Updating Developer $Developeremail"
                # Create a JSON payload with the fields that can be updated
                $json_template = @{
                    "email"     = $email
                    "firstName" = $firstname
                    "lastName"  = $lastname
                    "userName"  = $username
                    "status"    = $status
                }
                $reqPayload = $json_template | ConvertTo-Json
                Write-Host "Request Payload:"
                Write-Host $reqPayload
                $Uri = "$apigeeDomain/$Developeremail"
                Invoke-WebRequest -Uri $Uri -Method 'PUT' -ContentType 'application/json; charset=utf-8' -Body $reqPayload -Headers $headers | Select-Object -Expand Content
            }
        }
    }
    else {
        Write-Error "Developer Email Required For Update Action"
   	}
}
elseif ( $Action -eq "Delete" ) {
    if ( $DeveloperemailValid ) {
		
        Write-Host "Deleting Developer $Developeremail"
        $email = $Developeremail.ToLower()
        $Uri = "$apigeeDomain/$Developeremail"
        Invoke-WebRequest -Uri $Uri -Method 'DELETE' -ContentType 'application/json; charset=utf-8' -Headers $headers | Select-Object -Expand Content
		
    }
    else {
        Write-Error "Developer Email Required For Delete Action"
   	}
}
elseif ( ( $Action -eq "Create" -Or $Action -eq "Update" ) -And $adhocJsonDataValid) {
    if ( $Action -eq "Create" ) {
        $requestPayload = $AdhocJsonBody | ConvertFrom-Json | ConvertFrom-Json
        $email = $requestPayload.email.ToLower()
        $firstname = $requestPayload.firstname
        $lastname = $requestPayload.lastname
        $username = $requestPayload.username
        Write-Host "Creating Developer $Developeremail"
   
        $json_template = @{
            "email"     = $email.ToLower()
            "firstName" = $firstname
            "lastName"  = $lastname
            "userName"  = $username
        }
        $reqPayload = $json_template | ConvertTo-Json
        Write-Host $reqPayload
	
        Invoke-WebRequest -Uri $apigeeDomain -Method 'POST' -ContentType 'application/json; charset=utf-8' -Body $reqPayload -Headers $headers | Select-Object -Expand Content
    }
    elseif ( $Action -eq "Update") {
	
        $requestPayload = $AdhocJsonBody | ConvertFrom-Json | ConvertFrom-Json
        $email = $requestPayload.email.ToLower()
        $firstname = $requestPayload.firstname
        $lastname = $requestPayload.lastname
        $username = $requestPayload.username
        $status = $requestPayload.status
        Write-Host $email
        Write-Host "Updating Developer $email"
        # Create a JSON payload with the fields that can be updated
        $json_template = @{
            "email"     = $email
            "firstName" = $firstname
            "lastName"  = $lastname
            "userName"  = $username
            "status"    = $status
        }
        $reqPayload = $json_template | ConvertTo-Json
        Write-Host "Request Payload:"
        Write-Host $reqPayload
        $Uri = "$apigeeDomain/$email"
        Invoke-WebRequest -Uri $Uri -Method 'PUT' -ContentType 'application/json; charset=utf-8' -Body $reqPayload -Headers $headers | Select-Object -Expand Content
    } 
}
else {
    Write-Error "Invalid Action"
}
